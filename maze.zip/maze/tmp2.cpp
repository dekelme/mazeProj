//#pragma once
//#include"cell.h"
//#include"maze.h"
//#include"state.h"
//#include"generator.h"
//#include"searcher.h"
//#include"searchable.h"
//#include"bfs.h"
//
//using namespace std;
//
//
//
//*********************
//template<class type>
//class searchable {
//private:
//public:
//	searchable() = default;
//	~searchable() {}
//	virtual const type& getStartState() const = 0;
//	virtual const type& getGoalState() const = 0;
//	virtual vector<type*> getAllPossibleStates(type* curr) = 0;
//
//};
//
//
//***********************
//template<class type>
//class searcher 
//{
//public:
//	searcher() {}
//	virtual Solution<type> search(searchable<type>* sol) = 0;
//	virtual int getNumberOfEvaluated() = 0;
//	~searcher() {}
//};
//
//
//template<class type>
//class commonSearcher : public searcher<type> {
//public:
//	commonSearcher() : _evaluatedNodes(0) {};
//	~commonSearcher() {}
//	virtual int getNumberOfEvaluated() { return 0; }						// need to build
//
//protected:
//	int _evaluatedNodes;
//	priority_queue <type*> _openList;
//};
//
//
//template< class type>
//class state {
//public:
//	state(type pos) : _state(pos),_cost(0),_cameFrom(nullptr) {};
//	state(const state* pos)
//	{
//		type tmp = pos->_state;
//		_state = tmp;
//	}
//	~state() {}
//
//	double getStateCost()const { return _cost; };
//	type& getState(){ return _state; };
//
//	void setPrev(state* prev)
//	{
//		_cameFrom = prev;
//	}
//	state<type>* getPrev()const { return _cameFrom; };
//
//	bool operator==(state& other)
//	{
//		if (_state == other._state)
//			return true;
//
//		return false;
//
//		other._state;
//	}
//
//
//protected:
//	void setState(type state) { _state = state; };
//	type _state;
//	double _cost;
//	state<type>* _cameFrom;
//};
//
//class mazeState: public state<cell>
//{
//public:
//	mazeState(cell pos) : state(pos) {};
//	mazeState(const cell* pos) : state(*pos) {};
//	mazeState(string str , cell pos) : state(pos)
//	{
//
//		Position tmp = pos.getPos();
//
//		int x = tmp.getPos_x();
//		int y = tmp.getPos_y();
//
//		if (str == "UP")
//			this->setState((y - 1, x));
//
//		if (str == "RIGHT")
//			this->setState((y , x + 1));
//
//		if (str == "DOWN")
//			this->setState((y + 1, x));
//
//		if (str == "LEFT")
//			this->setState((y, x - 1));
//
//	}
//	mazeState(const mazeState* pos) : state(pos) {};
//	bool operator <(const mazeState& other) { return _cost < other._cost; };
//	~mazeState() {};
//
//	void calculateCost(double stepCost, mazeState* from)
//	{
//		if (from == nullptr)
//			_cost = 0;
//		else
//			_cost = from->_cost + stepCost;
//	}
//
//
//};
//
//class mazeSearchable : public searchable<mazeState>
//{
//public:
//	mazeSearchable(maze2d& maze) :searchable(), _maze(maze), _start(nullptr), _end(nullptr)
//	{
//		_start = new mazeState(_maze.getStartPosition());
//		_end = new mazeState(_maze.getStartPosition());
//		_stepCost = 10;
//	};
//
//	~mazeSearchable()
//	{
//		delete _start;
//		delete _end;
//	}
//
//	virtual const mazeState& getStartState()const
//	{
//		return *_start;
//	}
//
//	virtual const mazeState& getGoalState() const
//	{
//		return *_end;
//	}
//
//	virtual vector<mazeState*> getAllPossibleStates(const mazeState& curr)const
//	{
//		mazeState tmp = curr;
//		cell pos = tmp.getState();
//
//		vector<mazeState*> vec;
//		vector<string> moves;
//		moves = _maze.getpossibleMoves(pos.getPos());
//
//		while (!moves.empty())
//		{
//			string tmp = moves.back();
//			moves.pop_back();
//
//			vec.push_back(new mazeState(tmp, pos));
//		}
//
//		return vec;
//	}
//
//	double getStepCost()const { return _stepCost; };
//
//	void print()
//	{
//		_maze.print();
//		//int size = _maze.size();
//
//		////for (int i = 0; i < size; i++)
//		////{
//		////	for (int j = 0; j < size; j++)
//		////	{
//		////		bool top = _maze[i][j].getWall("top");
//		////		bool right = _maze[i][j].getWall("right");
//		////		bool bottom = _maze[i][j].getWall("bottom");
//		////		bool left = _maze[i][j].getWall("left");
//		////		printf("position: %d,%d . top: %d , right: %d , bottom: %d , left: %d . \n", i, j, top, right, bottom, left);
//		////	}
//		////}
//
//		////cout << endl;
//		////cout << endl;
//
//		//cout << "start: " << _start->getPos().getPos_y() << "," << _start->getPos().getPos_x() << endl;
//		//cout << "end: " << _end->getPos().getPos_y() << "," << _end->getPos().getPos_x() << endl;
//
//
//		//cout << endl;
//
//		//for (int i = 0; i < 2 * size + 1; i++)
//		//{
//		//	cout << "||";
//		//}
//
//
//		//cout << endl;
//
//		//for (int i = 0; i < size; i++)
//		//{
//		//	for (int j = 0; j < 2; j++)
//		//	{
//
//		//		for (int n = 0; n < size; n++)
//		//		{
//		//			bool t = _maze[i][n].getWall("top");
//		//			bool l = _maze[i][n].getWall("left");
//		//			bool b = _maze[i][n].getWall("bottom");
//		//			bool r = _maze[i][n].getWall("right");
//		//			if (n == 0)
//		//				cout << "||";
//
//		//			if (j == 0)
//		//			{
//		//				if (r)
//		//					cout << "  ||";
//
//		//				else
//		//					cout << "    ";
//		//			}
//		//			if (j == 1)
//		//			{
//		//				if (b)
//		//				{
//		//					cout << "||||";
//		//				}
//		//				else
//		//				{
//		//					if (r)
//		//						cout << "  ||";
//		//					else
//		//						cout << "    ";
//		//				}
//		//			}
//
//		//		}
//		//		cout << endl;
//		//	}
//		//}
//	}
//
//private:
//	maze2d _maze;
//	double _stepCost;
//	mazeState* _start;
//	mazeState* _end;
//};
//
//
//
//class BFS : public commonSearcher<mazeState>
//{
//public:
//	BFS() = default;
//	~BFS()
//	{
//		int size = _openList.size();
//		mazeState* tmp;
//		for (int i = 0; i < size; i++)
//		{
//			tmp = _openList.top();
//			_openList.pop();
//
//			delete tmp;
//		}
//	}
//
//	virtual Solution<mazeState> search(searchable<mazeState>* s)
//	{
//		mazeSearchable* ms = dynamic_cast<mazeSearchable*>(s);
//		mazeState end = ms->getGoalState();
//		Position endPos = end.getState().getPos();
//
//
//
//		mazeState* start = new mazeState(ms->getStartState());
//		double cost = ms->getStepCost();
//
//		start->calculateCost(cost, nullptr);
//
//		this->_openList.push(start);												//push first node
//
//		while (!this->_openList.empty())
//		{
//			mazeState* curState = this->_openList.top();
//			this->_openList.pop();
//			curState->getState().setVisited(true);
//			this->_evaluatedNodes++;
//
//			if (curState->getState().getPos() == endPos)
//			{
//				Solution<mazeState> ans;
//				while (curState != nullptr)
//				{
//					ans.pushState(*curState);
//
//					state<cell>* tmp = curState->getPrev();
//
//					curState = dynamic_cast<mazeState*>(tmp);
//				}
//
//
//				return ans;
//			}
//
//			vector<mazeState*> tmp = ms->getAllPossibleStates(curState);		// get next possible states
//
//			for (int i = 0; i < tmp.size(); i++)
//			{
//				if (tmp[i]->getState().isVisited())
//					continue;
//
//				tmp[i]->setPrev(curState);
//				tmp[i]->calculateCost(cost, curState);
//				this->_openList.push(tmp[i]);
//			}
//		}
//	}
//};
//
//
//
//**********************************
//class state {
//public:
//	state(state* prev, double cost = 0): _cameFrom(prev), _cost(cost){};
//	~state() {};
//
//	virtual double getStateCost()const{ return  _cost; };
//	state* getPrev(){ return _cameFrom; };
//	void setPrev(state* prev) { _cameFrom = prev; };
//	virtual bool operator<(state* other)const{ return _cost < other->_cost; };
//	virtual bool operator == (state* other)const = 0;
//
//protected:
//	double _cost;
//	state* _cameFrom;
//};
//
//class mazeState : public state
//{
//public:
//	mazeState( cell* pos , state* prev):state(prev), _pos(pos) {};
//	mazeState():state(nullptr){};
//
//	cell* getState(){ return _pos; };
//	bool operator <(const mazeState& other) { return _cost < other._cost; };
//	~mazeState() {};
//
//	void calculateCost(double stepCost, mazeState* from)
//	{
//		if (from == nullptr)
//			_cost = 0;
//		else
//			_cost = from->_cost;
//	}
//
//
//	virtual bool operator == (state* other)const
//	{
//		mazeState* tmp = dynamic_cast<mazeState*>(other);
//		if (_pos == tmp->_pos)
//			return true;
//
//		return false;
//	}
//
//private:
//	cell* _pos;
//};
//
//
//
//**********************************
//class mazeSearchable : public searchable<mazeState>
//{
//public:
//	mazeSearchable(maze2d& maze) :searchable(), _maze(maze), _start(nullptr), _end(nullptr)
//	{
//		_start = new mazeState(_maze.getStartPosition(), nullptr);
//		_end = new mazeState(_maze.getGoalPosition(), nullptr);
//		_stepCost = 10;
//	};
//
//	~mazeSearchable()
//	{
//		delete _start;
//		delete _end;
//	}
//
//	virtual const mazeState& getStartState()const
//	{
//		return *_start;
//	}
//
//	virtual const mazeState& getGoalState() const
//	{
//		return *_end;
//	}
//
//	virtual vector<mazeState*> getAllPossibleStates(mazeState* curr)
//	{
//		
//		Position tmp = curr->getState()->getPos();
//		
//		vector<mazeState*> vec;
//		vector<string> moves;
//		moves = _maze.getpossibleMoves(tmp);
//
//		while (!moves.empty())
//		{
//			string str = moves.back();
//			moves.pop_back();
//			cell* pos = _maze.findCell(str, curr->getState());
//
//			vec.push_back(new mazeState (pos, curr));
//		}
//
//		return vec;
//	}
//
//	double getStepCost()const { return _stepCost; };
//
//	void print()
//	{
//		_maze.print();
//	}
//
//private:
//	maze2d _maze;
//	double _stepCost;
//	mazeState* _start;
//	mazeState* _end;
//};
//
//
//*****************************
//class BFS : public commonSearcher<mazeState>
//{
//public:
//	BFS() = default;
//	~BFS()
//	{
//		int size = _openList.size();
//		mazeState* tmp;
//		for (int i = 0; i < size; i++)
//		{
//			tmp = _openList.top();
//			_openList.pop();
//
//			delete tmp;
//		}
//	}
//
//	virtual Solution<mazeState> search(searchable<mazeState>* s)
//	{
//		mazeSearchable* ms = dynamic_cast<mazeSearchable*>(s);
//		mazeState end = ms->getGoalState();
//		Position endPos = end.getState()->getPos();
//
//	
//		ms->print();
//
//		cout << "done" << endl;
//
//		mazeState* start = new mazeState(ms->getStartState());
//		double cost = ms->getStepCost();
//
//		start->calculateCost(cost, nullptr);
//
//		this->_openList.push(start);												//push first node
//
//		while (!this->_openList.empty())
//		{
//			mazeState* curState = this->_openList.top();
//			this->_openList.pop();
//
//			curState->getState()->setVisited(true);
//
//			this->_evaluatedNodes++;
//
//			if (curState->getState()->getPos() == endPos)
//			{
//				Solution<mazeState> ans;
//				while (curState != nullptr)
//				{
//					ans.pushState(*curState);
//
//					state* tmp = curState->getPrev();
//		
//					curState = dynamic_cast<mazeState*>(tmp);
//				}
//
//
//				return ans;
//			}
//
//			vector<mazeState*> tmp = ms->getAllPossibleStates(curState);		// get next possible states
//			
//			for (int i = 0; i < tmp.size(); i++)
//			{
//				if (tmp[i]->getState()->isVisited())
//					continue;
//
//				tmp[i]->setPrev(curState);
//				tmp[i]->calculateCost(cost, curState);
//				this->_openList.push(tmp[i]);
//			}	
//		}
//	}
//};
//
//
//
//
//
//
//
//
//
//
//
//
