#pragma once
#include"searchable.h"
#include<vector>

using namespace std;


	//template<class type>
	//Solution<type>::~Solution() {};

	//template<class type>
	//void Solution<type>::Solution::pushState(type a)
	//{
	//	_solution.insert(_solution.begin(), a);
	//}

	//template<class type>
	//vector<type> Solution<type>::getSolution()const { return _solution; };

	//template<class type>
	//void Solution<type>::print()
	//{
	//	int size = _solution.size();
	//	for (int i = 0; i < size; i++)
	//	{
	//		cout << "state " << i << " :" << _solution[i].getState()->getPos() << endl;
	//	}
	//}






	mazeSearchable::mazeSearchable(Maze2d& maze) :searchable(), _maze(maze), _start(nullptr), _end(nullptr)
	{
		_start = new mazeState(_maze.getStartPosition(), nullptr);
		_end = new mazeState(_maze.getGoalPosition(), nullptr);
		_stepCost = 1.5;
	};

	mazeSearchable::~mazeSearchable()
	{
		delete _start;
		delete _end;
	}

	const mazeState& mazeSearchable::getStartState()const
	{
		return *_start;
	}

	const mazeState& mazeSearchable::getGoalState() const
	{
		return *_end;
	}

	vector<mazeState*> mazeSearchable::getAllPossibleStates(mazeState* curr)
	{
		/*validtion*/
		if (curr == nullptr)
			throw "Maze state Error";
		/*validtion*/
		Position tmp = curr->getState()->getPos();

		vector<mazeState*> vec;
		vector<string> moves;
		moves = _maze.getPossibleMoves(tmp);

		while (!moves.empty())
		{
			string str = moves.back();
			moves.pop_back();
			cell* pos = _maze.findCell(str, curr->getState());

			vec.push_back(new mazeState(pos, curr));
		}

		return vec;
	}

	double mazeSearchable::getStepCost()const { return _stepCost; };

	void mazeSearchable::print()
	{
		//_maze.print();
	}

