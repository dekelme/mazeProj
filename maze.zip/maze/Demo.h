#pragma once
#include"generator.h"
#include"bfs.h"
#include"Astar.h"

class Demo
{
public:
    Demo();
    ~Demo();
    void run(int size, string name);
private:
    Maze2dGenerator* _gen;
    Solution<mazeState> _sol;
    searcher<mazeState>* _bfs;
    searcher<mazeState>* _Astar;
    searchable<mazeState>* _msearch;
};
