#include"Demo.h"




Demo::Demo() : _gen(nullptr), _sol(), _bfs(nullptr), _msearch(nullptr), _Astar(nullptr)
{
    _gen = new myMaze2dGenerator();
    _bfs = new BFS;
    _Astar = new Astar;

}

Demo::~Demo()
{
    delete _gen;
    delete  _bfs;
    delete _Astar;
    delete _msearch;
};

void Demo::run(int size, string name)
{
    Astar* a_star = dynamic_cast<Astar*>(_Astar);
    Maze2d maze = _gen->generate(size, name);

    _msearch = new mazeSearchable(maze);

    _sol = _bfs->search(_msearch);
    int bfs_nodes = _bfs->getNumberOfEvaluated();
    maze.print(&_sol.getSolution());

    cout << endl;

    a_star->setHuristic(new MazeManheten());
    _sol = a_star->search(_msearch);
    int a1 = a_star->getNumberOfEvaluated();
    maze.print(&_sol.getSolution());

    cout << endl;

    a_star->setHuristic(new MazeAirDistance());
    _sol = a_star->search(_msearch);
    int a2 = a_star->getNumberOfEvaluated();
    maze.print(&_sol.getSolution());

    cout << endl;
    cout << "number of evaluated nodes for bfs: " << bfs_nodes << endl;
    cout << "number of evaluated nodes for A* manheten: " << a1 << endl;
    cout << "number of evaluated nodes for A* air dist: " << a2 << endl;
    cout << endl;
}


