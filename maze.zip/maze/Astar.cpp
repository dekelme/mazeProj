//#include "bfs.h"
//#include <math.h>
//#include <map>
//
//
//template<class type>
//class heuristic
//{
//public:
//	heuristic() = default;
//	~heuristic() = default;
//	virtual double calculate(type* curr, type* goal) = 0;
//};
//
//
//
//class MazeAirDistance : public heuristic<mazeState<cell>>
//{
//public:
//	MazeAirDistance() = default;
//	~MazeAirDistance() = default;
//	virtual double calculate(mazeState<cell>* curr, mazeState<cell>* goal, double step_cost)
//	{
//		pair<int, int> from = curr->getState()->getPos().getPosition();
//		pair<int, int> to = goal->getState()->getPos().getPosition();
//
//		int row_d = from.first - to.first;
//		int col_d = from.second - to.second;
//
//		row_d *= row_d < 0 ? -1 : 1;
//		col_d *= col_d < 0 ? -1 : 1;
//
//		return sqrt(pow(row_d, 2) + pow(col_d, 2)) * step_cost;
//	}
//
//};
//
//
//class MazeManheten : public heuristic<mazeState<cell>>
//{
//public:
//	MazeManheten() = default;
//	~MazeManheten() = default;
//	virtual double calculate(mazeState<cell>* curr, mazeState<cell>* goal, double step_cost)
//	{
//		pair<int, int> from = curr->getState()->getPos().getPosition();
//		pair<int, int> to = goal->getState()->getPos().getPosition();
//
//		int row_d = from.first - to.first;
//		int col_d = from.second - to.second;
//
//		row_d *= row_d < 0 ? -1 : 1;
//		col_d *= col_d < 0 ? -1 : 1;
//
//		double ans = row_d + col_d;
//		return ans * step_cost;
//	}
//
//};
//
//
//
//class Astar : public commonSearcher<mazeState<cell>>
//{
//public:
//	Astar(heuristic< mazeState<cell>>* h) : _h(h) {};
//	~Astar() = default;
//
//	virtual Solution<mazeState<cell>> search(searchable<mazeState<cell>>* s)
//	{
//		mazeSearchable* ms = dynamic_cast<mazeSearchable*>(s);
//		mazeState<cell> end = ms->getGoalState();
//		Position endPos = end.getState()->getPos();
//		Solution<mazeState<cell>> ans;
//
//		mazeState<cell>* start = new mazeState<cell>(ms->getStartState());
//
//		double stepCost = ms->getStepCost();
//		double h_cost = _h->calculate(start, &end);										// calculate huristic cost
//		start->calculateCost(stepCost, start, h_cost);									// calculate cost
//
//		this->_openList.push(start);													// start in open liset
//
//
//		while (!this->_openList.empty())												// while open not empty
//		{
//			mazeState<cell>* curr = this->_openList.top();								// get best node
//			_openList.pop();
//
//
//			if (curr->getState()->getPos() == endPos)
//			{
//				while (curr != nullptr)
//				{
//					ans.pushState(*curr);
//					State<cell>* tmp = curr->getPrev();
//					curr = dynamic_cast<mazeState<cell>*>(tmp);
//				}
//				return ans;
//			}
//
//			vector<mazeState<cell>*> tmp = ms->getAllPossibleStates(curr);		// get next possible states
//
//			for (int i = 0; i < (signed)tmp.size(); i++)
//			{
//
//				h_cost = _h->calculate(tmp[i], &end);
//				tmp[i]->calculateCost(stepCost, curr, h_cost);
//
//				Position p = tmp[i]->getState()->getPos();
//				auto it = _openSeen.find(p);
//				if (it != _openSeen.end())
//				{
//					if (_openSeen[p] <= tmp[i]->getStateCost())
//					{
//						delete tmp[i];
//						continue;
//					}
//				}
//
//				it = _closedSeen.find(p);
//				if (it != _closedSeen.end())
//				{
//					if (_closedSeen[p] <= tmp[i]->getStateCost())
//					{
//						delete tmp[i];
//						continue;
//					}
//				}
//
//				tmp[i]->setPrev(curr);
//				this->_openList.push(tmp[i]);
//			}
//
//			_closedSeen[curr->getState()->getPos()] = curr->getStateCost();					// remember pos and cost in closed
//		}
//
//		return ans;
//	}
//
//private:
//	heuristic<mazeState<cell>>* _h;
//	map<Position, double> _openSeen;
//	map<Position, double> _closedSeen;
//
//};
//
