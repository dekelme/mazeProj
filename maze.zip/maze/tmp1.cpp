//#include<iostream>
//#include<algorithm>
//#include<vector>
//#include<string>
//#include<cstdlib>
//#include<time.h>
//#include<stack>
//#include<random>
//using namespace std;
//
//class mazeInterface;
//
//
//class mazePosition
//{
//public:
//	mazePosition(int y = 0, int x = 0) : _pos(y, x) {};
//	~mazePosition();
//	int getPos_x()const { return _pos.second; };
//	int getPos_y()const { return _pos.first; };
//	pair<int, int> getPosition()const { return _pos; };
//	void setPos_x(int x) { _pos.second = x; };			// add checks?
//	void setPos_y(int y) { _pos.first = y; };
//private:
//	pair<int, int> _pos;
//};
//
//
//mazePosition::~mazePosition()
//{
//}
//
//
//
//
//
//class cell
//{
//public:
//	cell(int x = 0 , int y = 0) : _top(true), _right(true), _bottom(true), _left(true), _visited(false), _position(y,x){};
//	~cell() = default;
//	bool isVisited() const { return _visited; };
//	void setVisited() { _visited = true; };
//	mazePosition getPos()const { return _position; };
//	vector<pair<int, int>> getAdjacents()const { return _adjacent; };
//
//	void setCords_adjencts(int y, int x)
//	{ 
//		_position.setPos_x(x);
//		_position.setPos_y(y);
//		_adjacent.push_back({ y - 1,x });
//		_adjacent.push_back({ y ,x + 1 });
//		_adjacent.push_back({ y + 1 ,x });
//		_adjacent.push_back({ y ,x -1 });
//	};
//
//	 bool getWall(string str) const
//	 {
//		 if (str == "top")
//			 return _top;
//		 if (str == "right")
//			 return _right;
//		 if (str == "bottom")
//			 return _bottom;
//		 if (str == "left")
//			 return _left;
//	 }
//
//	void removeWall(string str)
//	{
//		if (str == "top")
//			_top = false;
//		if (str == "right")
//			_right = false;
//		if (str == "bottom")
//			_bottom = false;
//		if (str == "left")
//			_left = false;
//	}
//
//private:
//	bool _top;
//	bool _right;
//	bool _bottom;
//	bool _left;
//	bool _visited;
//	vector<pair<int, int>> _adjacent;
//	mazePosition _position;
//};
//
//
//
//class myAlgorithem
//{
//public:
//	myAlgorithem() {};
//	virtual void runAlgorithem() = 0;
//private:
//
//};
//
//
//class mazeCreationAlgorithem : public myAlgorithem
//{
//public:
//	mazeCreationAlgorithem(int size): myAlgorithem(), _start(0,0),_end(0,0) 			// create maze in size wanted 
//	{
//		_maze.resize(size);
//		for (int i = 0; i < size; i++)
//		{
//			_maze[i] = vector<cell>(size);
//			for (int j = 0; j < size; j++)
//			{
//				_maze[i][j].setCords_adjencts(i,j);
//				_list.push(&_maze[i][j]);
//			}
//		}
//	}
//
//	~mazeCreationAlgorithem() = default;
//
//	virtual void runAlgorithem() = 0;
//
//	void removeWalls(cell* one, cell* two)
//	{
//		string one_wall;
//		string two_wall;
//		
//		mazePosition one_pos = one->getPos();
//		mazePosition two_pos = two->getPos();
//
//		if (one_pos.getPos_x() == two_pos.getPos_x())
//		{
//			if (one_pos.getPos_y() < two_pos.getPos_y())
//			{
//				one_wall = "bottom";
//				two_wall = "top";
//			}
//			else
//			{
//				one_wall = "top";
//				two_wall = "bottom";
//			}
//		}
//		else
//		{
//			if (one_pos.getPos_x() > two_pos.getPos_x())
//			{
//				one_wall = "left";
//				two_wall = "right";
//			}
//			else
//			{
//				one_wall = "right";
//				two_wall = "left";
//			}
//		}
//
//		one->removeWall(one_wall);
//		two->removeWall(two_wall);
//	}
//
//	int getRandomNumber()
//	{
//		std::random_device rd1;
//		std::uniform_int_distribution<int> distribution(0, 8191);
//		int tmp = distribution(rd1);
//		return tmp;
//	}
//
//	cell* getRandomadjacent(cell* ptr)		
//	{
//		vector <pair<int, int>> ans;
//		vector <pair<int, int>> tmp = ptr->getAdjacents();
//		int size = _maze.size();
//		int num = 4;
//
// 		for (int i = 3; i >= 0; i--)
//		{
//			if (tmp[i].first == -1 || tmp[i].first >= size || tmp[i].second == -1 || tmp[i].second >= size || _maze[tmp[i].first][tmp[i].second].isVisited())
//				num--;
//			else
//				ans.push_back(tmp[i]);
//		}
//
//		if (num == 0)
//			return nullptr;
//
//
//
//		int index = getRandomNumber();
//		index %= num;
//		
//		return &_maze[ans[index].first][ans[index].second];
//	};
//
//
//protected:
//	vector <vector<cell>> _maze;
//	stack<cell*> _list;
//	mazePosition _start;
//	mazePosition _end;
//};
//
//
//
//class creationAlgorithem : public myAlgorithem
//{
//public:
//	creationAlgorithem(int size) : myAlgorithem() 			// create maze in size wanted 
//	{
//		_maze.resize(size);
//		for (int i = 0; i < size; i++)
//		{
//			_maze[i] = vector<cell*>(size);
//			for (int j = 0; j < size; j++)
//			{
//				_maze[i][j] = new cell(i, j);
//				_maze[i][j]->setCords_adjencts(i, j);
//				_list.push(_maze[i][j]);
//			}
//		}
//	}
//
//	~creationAlgorithem() = default;
//
//	void removeWalls(cell* one, cell* two)
//	{
//		string one_wall;
//		string two_wall;
//
//		mazePosition one_pos = one->getPos();
//		mazePosition two_pos = two->getPos();
//
//		//pair<int, int> one_pos = tmp1.getPosition();
//		//pair<int, int> two_pos = tmp2.getPosition();
//
//		if (one_pos.getPos_x() == two_pos.getPos_x())
//		{
//			if (one_pos.getPos_y() < two_pos.getPos_y())
//			{
//				one_wall = "bottom";
//				two_wall = "top";
//			}
//			else
//			{
//				one_wall = "top";
//				two_wall = "bottom";
//			}
//		}
//		else
//		{
//			if (one_pos.getPos_x() > two_pos.getPos_x())
//			{
//				one_wall = "left";
//				two_wall = "right";
//			}
//			else
//			{
//				one_wall = "right";
//				two_wall = "left";
//			}
//		}
//
//		one->removeWall(one_wall);
//		two->removeWall(two_wall);
//	}
//
//	pair<int, int> getRandomadjacent(cell* ptr)
//	{
//		vector <pair<int, int>> ans;
//		vector <pair<int, int>> tmp = ptr->getAdjacents();
//		int size = _maze.size();
//		int num = 4;
//
//		for (int i = 3; i >= 0; i--)
//		{
//			if (tmp[i].first == -1 || tmp[i].first >= size || tmp[i].second == -1 || tmp[i].second >= size || _maze[tmp[i].first][tmp[i].second]->isVisited())
//				num--;
//			else
//				ans.push_back(tmp[i]);
//		}
//
//		if (num == 0)
//			return pair<int, int>(-1, -1);
//
//		std::random_device rd1;
//		std::uniform_int_distribution<int> distribution(0, 8191);
//		int index = distribution(rd1);
//
//		index = index % num;
//
//		return ans[index];
//	};
//
//	virtual void run
//
//
//
//private:
//	vector <vector<cell*>> _maze;
//	stack<cell*> _list;
//};
//
//class simplMazeCereation : public mazeCreationAlgorithem
//{
//public:
//	simplMazeCereation(int size) : mazeCreationAlgorithem(size) {};			// create maze in size wanted 
//	~simplMazeCereation() = default;
//	void setRandomStartEnd()
//	{
//		pair<int, int> pos = _start.getPosition();
//		pair<int, int> pos2 = _end.getPosition();
//		int size = _maze.size();
//		int num = getRandomNumber();
//		num %= 4;
//		
//		switch (num)
//		{
//		case 0 :			// top
//			pos.first = 0;
//			pos.second = getRandomNumber() % size;
//
//			pos2.first = size -1;
//			pos2.second = getRandomNumber() % size;
//			break;
//
//		case 1:				// right
//			pos.first = getRandomNumber() % size;;
//			pos.second = size - 1;
//
//			pos2.first = getRandomNumber() % size;;
//			pos2.second = 0;
//			break;
//
//		case 2:				// bottom
//			pos.first = size - 1;
//			pos.second = getRandomNumber() % size;
//
//			pos2.first = 0;
//			pos2.second = getRandomNumber() % size;
//			break;
//
//		case 3:				// left
//			pos.first = getRandomNumber() % size;;
//			pos.second = 0;
//
//			pos2.first = getRandomNumber() % size;;
//			pos2.second = size -1;
//			break;
//		}
//
//		_start.setPos_y(pos.first);
//		_start.setPos_x(pos.second);
//		_end.setPos_y(pos2.first);
//		_end.setPos_x(pos2.second);
//	}
//
//	virtual void runAlgorithem()
//	{
//		setRandomStartEnd();
//		pair<int, int>pos1 = _start.getPosition();
//		pair<int, int> pos2;
//		pair<int, int>end = _end.getPosition();
//
//		cell* curr = &_maze[pos1.first][pos1.second];
//		cell* next;
//		int size = _maze.size();
//		bool done = false;
//
//		for (int i = 0; i < size; i++)				// random start
//		{
//			next = getRandomadjacent(curr);
//			if (next != nullptr)
//			{
//				removeWalls(curr, next);
//				curr = next;
//			}
//		}
//
//		while (pos1 != end)									// go to end
//		{
//			pos2 = pos1;
//			if (pos2.first > end.first)
//				pos2.first--;
//			else if (pos2.first < end.first)
//				pos2.first++;
//
//			if (pos2 == pos1)
//			{
//				if (pos2.second > end.second)
//					pos2.second--;
//				else if (pos2.second < end.second)
//					pos2.second++;
//			}
//
//			removeWalls(&_maze[pos1.first][pos1.second], &_maze[pos2.first][pos2.second]);
//			pos1 = pos2;
//		}
//
//		int y, x;
//		for (int i = 0; i < size; i++)
//		{
//			y = getRandomNumber() % size;
//			x = getRandomNumber() % size;
//			curr = &_maze[y][x];
//			next = getRandomadjacent(curr);
//			if (next == nullptr)
//				continue;
//			removeWalls(curr, next);
//		}
//
//	};
//
//};
//
//class myMazeCreation : public mazeCreationAlgorithem
//{
//public:
//	myMazeCreation(int size) : mazeCreationAlgorithem(size) {};			// create maze in size wanted 
//	~myMazeCreation() = default;
//
//	virtual void runAlgorithem()
//	{
//		cell* curr = &_maze[0][0];
//		cell* next = nullptr;
//
//		pair<int, int> position;
//		curr->setVisited();
//
//		while (!_list.empty())						// while stack not empty
//		{
//			next = getRandomadjacent(curr);			// if any neigbhors
//			if (next != nullptr)
//			{
//				removeWalls(curr, next);							// remove walls
//				_list.push(curr);									// insert for further work
//				curr = next;
//				curr->setVisited();
//
//			}
//			else
//			{
//				curr = _list.top();
//				_list.pop();
//			}
//		}
//	};
//
//	void print()
//	{
//		int size = _maze.size();
//
//		for (int i = 0; i < size; i++)
//		{
//			for (int j = 0; j < size; j++)
//			{
//				bool top = _maze[i][j].getWall("top");
//				bool right = _maze[i][j].getWall("right");
//				bool bottom = _maze[i][j].getWall("bottom");
//				bool left = _maze[i][j].getWall("left");
//				printf("position: %d,%d . top: %d , right: %d , bottom: %d , left: %d . \n", i, j, top, right, bottom, left);
//			}
//		}
//
//		cout << endl;
//		cout << endl;
//
//
//		for (int i = 0; i < 2 * size + 1; i++)
//			cout << "||";
//
//		cout << endl;
//
//		for (int i = 0; i < size; i++)
//		{
//			for (int j = 0; j < 2; j++)
//			{
//
//				for (int n = 0; n < size; n++)
//				{
//					bool t = _maze[i][n].getWall("top");
//					bool l = _maze[i][n].getWall("left");
//					bool b = _maze[i][n].getWall("bottom");
//					bool r = _maze[i][n].getWall("right");
//					if (n == 0)
//						cout << "||";
//
//					if (j == 0)
//					{
//						if (r)
//							cout << "  ||";
//
//						else
//							cout << "    ";
//					}
//					if (j == 1)
//					{
//						if (b)
//						{
//							cout << "||||";
//						}
//						else
//						{
//							if (r)
//								cout << "  ||";
//							else
//								cout << "    ";
//						}
//					}
//
//				}
//				cout << endl;
//			}
//		}
//	}
//
//};
//
//class Maze2dGenerator
//{ 
//public:
//	Maze2dGenerator();
//	~Maze2dGenerator();
//
//	virtual mazeInterface* generate() = 0;
//	virtual string mesureAlgorithemTime() = 0;
//
//};
//
// 
//class myMaze2dGenerator: public Maze2dGenerator
//{
//public:
//	myMaze2dGenerator(myAlgorithem* alg) :Maze2dGenerator(), _alg(alg) {};
//	~myMaze2dGenerator();
//	virtual mazeInterface* generate()
//	{
//		_alg->runAlgorithem();
//	}
//	virtual string mesureAlgorithemTime();
//
//
//private:
//	myAlgorithem* _alg;
//};
//
//
//
//
//int main()
//{
//
//  	myMazeCreation a(15);
//	a.runAlgorithem();
//	a.print();
//
//}
//
//
