//#pragma once
//#include"cell.h"
//
//
//template<class type>
//class State {
//public:
//	State(type* state, State* prev, double cost = 0);
//	~State();
//
//	virtual double getStateCost()const;
//	virtual double getState_Gcost()const;
//	virtual double getState_h_cost()const;
//	State* getPrev();
//	type* getState();
//	void setPrev(State* prev);
//	virtual bool operator<(State* other)const = 0;
//	virtual bool operator == (State* other)const = 0;
//
//protected:
//	double _cost;
//	double _h_cost;
//	State* _cameFrom;
//	type* _state;
//};
//
//
//template<class type>
//class mazeState : public State<type>
//{
//public:
//	mazeState(type* pos, State<type>* prev, double cost = 0);
//	~mazeState();
//	void calculateCost(double stepCost, mazeState* from, double h_cost = 0);
//	virtual bool operator == (State<type>* other)const;
//	virtual bool operator<(State<type>* other)const;
//
//};
//
//
//template<class type>
//State<type>::State(type* state, State* prev, double cost) : _cameFrom(prev), _cost(cost), _state(state), _h_cost(0) {};
//
//template<class type>
//State<type>::~State() {};
//
//template<class type>
//double State<type>::getStateCost()const { return   this->_h_cost + this->_cost; };
//
//template<class type>
//double State<type>::getState_h_cost()const { return   this->_h_cost; };
//
//template<class type>
//double State<type>::getState_Gcost()const { return  this->_cost; };
//
//template<class type>
//State<type>* State<type>::getPrev() { return this->_cameFrom; };
//
//template<class type>
//void State<type>::setPrev(State* prev) { this->_cameFrom = prev; };
//
//
//
//template<class type>
//type* State<type>::getState() { return this->_state; };
//
//
//
//
//
//// maze state         
//
//template<class type>
//mazeState<type>::mazeState(type* pos, State<type>* prev, double cost) :State<type>(pos,prev,cost) {};
//
//template<class type>
//mazeState<type>::~mazeState() {};
//
//template<class type>
//bool mazeState<type>::operator<(State<type>* other)const
//{
//	//cout << "left: " << this->_cost + this->_h_cost << " right: " << other->getStateCost()<< endl;
//	//if (this->_cost + this->_h_cost < other->getStateCost())
//	//{
//	//	cout << "choose left" << endl;
//	//	return true;
//	//}
//
//	//cout << "choose right" << endl;
//	//return false;
//	return false;
//};
//
//
//template<class type>
//void mazeState<type>::calculateCost(double stepCost, mazeState* from, double h_cost)
//{
//	this->_cost = 0;
//	this->_h_cost = 0;
//	if (from == this)
//		this->_cost = 0;
//	else
//		this->_cost = from->_cost + stepCost;
//
//	this->_h_cost = h_cost;
//}
//
//
//template<class type>
//bool mazeState<type>::operator == (State<type>* other)const
//{
//	mazeState* tmp = dynamic_cast<mazeState*>(other);
//	if (this->_state == tmp->_state)
//		return true;
//
//	return false;
//}
//
//
//


#pragma once
#include"cell.h"


template<class type>
class State {
public:
	State(type* state, State* prev, double cost = 0);
	~State();

	virtual double getStateCost()const;
	virtual double getState_Gcost()const;
	virtual double getState_h_cost()const;
	State* getPrev();
	type* getState();
	void setPrev(State* prev);
	virtual bool operator<(State* other)const = 0;
	virtual bool operator == (State* other)const = 0;

protected:
	double _cost;
	double _h_cost;
	State* _cameFrom;
	type* _state;
};




class mazeState : public State<cell>
{
public:
	mazeState(cell* pos, State<cell>* prev, double cost = 0);
	~mazeState();
	void calculateCost(double stepCost, mazeState* from, double h_cost = 0);
	virtual bool operator == (State<cell>* other)const;
	virtual bool operator<(State<cell>* other)const;

};

class myComperator
{
public:
	int operator() (mazeState* p1, mazeState* p2) { return p1->getStateCost() > p2->getStateCost(); };
};

template<class type>
State<type>::State(type* state, State* prev, double cost) : _cameFrom(prev), _cost(cost), _state(state), _h_cost(0) {};

template<class type>
State<type>::~State() {};

template<class type>
double State<type>::getStateCost()const { return   this->_h_cost + this->_cost; };

template<class type>
double State<type>::getState_h_cost()const { return   this->_h_cost; };

template<class type>
double State<type>::getState_Gcost()const { return  this->_cost; };

template<class type>
State<type>* State<type>::getPrev() { return this->_cameFrom; };

template<class type>
void State<type>::setPrev(State* prev) { this->_cameFrom = prev; };

template<class type>
type* State<type>::getState() { return this->_state; };








