#pragma once
#include"cell.h"
#include<iostream>

//		Position

ostream& operator<<(ostream& output, const Position& pos) {
	/*validtion*/
	if (/*output.EOF() || */pos == nullptr)
		throw "Position Error";
	/*validtion*/
	output << "{" << pos.getPos_y() << "," << pos.getPos_x() << "}";
	return output;
}

//Position::Position(const cell* pos)
//{
//	_pos = pos->getPos().getPosition();
//}

bool Position::operator ==(const Position& other)const
{
	/*validtion*/
	if (other == nullptr )
		throw "Position Error";
	/*validtion*/
	if (getPosition() == other.getPosition())
		return true;

	return false;
}


//    cell

Position::Position(const cell* pos)
{
	/*validtion*/
	if (pos == nullptr)
		throw "Postion Error";
	/*validtion*/
	_pos = pos->getPos().getPosition();
}

void cell::setPos(int y, int x)
{
	_position.setPos_x(x);
	_position.setPos_y(y);
	_adjacent.push_back({ y - 1,x });
	_adjacent.push_back({ y ,x + 1 });
	_adjacent.push_back({ y + 1 ,x });
	_adjacent.push_back({ y ,x - 1 });
};

void cell::setAdjencts()
{
	int x = _position.getPos_x();
	int y = _position.getPos_y();

	_adjacent.push_back({ y - 1,x });
	_adjacent.push_back({ y ,x + 1 });
	_adjacent.push_back({ y + 1 ,x });
	_adjacent.push_back({ y ,x - 1 });
};

bool cell::getWall(string str) const
{
	if (str == "top")
		return _top;
	if (str == "right")
		return _right;
	if (str == "bottom")
		return _bottom;
	if (str == "left")
		return _left;
}

void cell::removeWall(string str)
{
	if (str == "top")
		_top = false;
	if (str == "right")
		_right = false;
	if (str == "bottom")
		_bottom = false;
	if (str == "left")
		_left = false;
};