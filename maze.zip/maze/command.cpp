#pragma once
#include"Demo.h"
#include "maze.h"
#include "dirent.h"
#include <filesystem>
#include <string>
#include <iostream>


class command {
public:
	virtual void execute() = 0;
	bool contEnd(string str, string end)
	{
		if (str.length() >= end.length())
			return (0 == str.compare(str.length() - end.length(), end.length(), end));
		else
			return false;
	}
};

//class generateMazeCommand : public command {
//private:
//	maze _myMaze;
//	string _name;
//	int _size;
//	myMaze2dGenerator _generate;
//public:
//	generateMazeCommand(const maze& mymaze, string name, int size) : _myMaze(mymaze), _name(name), _size(size) {}
//	void execute()
//	{
//		_myMaze = _generate.generate(_size);
//		cout << "Maze " << _name << "is ready" << endl;
//	}
//};


class dirCommand : public command
{
private:
	string _dirName;
public:
	dirCommand() = default;
	~dirCommand() = default;
	void setDirName(string dir_name) { _dirName = dir_name; };

	virtual void execute() {
		DIR* _dir;
		struct dirent* dire;
		struct stat sta;
		_dir = opendir(_dirName.c_str());
		if (!_dir) {
			cout << "Not found" << endl;
		}
		//while ((dire = readdir(_dir)) != NULL)
		//{
		//	if (dire->d_name[0] != '.') {
		//		string path = string(dir_name) + "/" + string(dire->d_name);
		//		cout << path << endl;
		//		stat(path.c_str(), &sta);
		//		if (S_ISDIR(sta.st_mode)) {
		//			execute((char*)path.c_str());
		//		}
		//	}
		//}
		closedir(_dir);
	}
};



//class displayCommand : public command {
//private:
//	maze _myMaze;
//	string _name;
//	Maze2dGenerator* _print;
//public:
//	displayCommand(const maze& mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		cout << _name << endl;
//		_print.print();
//	}
//};
//

class saveMazeCommand : public command
{
private:
	maze* _myMaze;
	string _name;
	ofstream& out_file;
public:
	saveMazeCommand() : {}
	void execute()
	{
		char* sizeN = _strlen(_name);
		out_file.write((char*)&sizeN, sizeof(int));
			out_file.write(_name, sizeN);
		vector<char> mymaze = compress(_myMaze);
		for (int i = 0; i < myMaze.size(); i++)
			out_file.write((vector<char>) & mymaze[i], sizeof(vector<char>));
	}
}

//class saveMazeCommand : public command
//{
//private:
//	maze* _myMaze;
//	string _name;
//public:
//	saveMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		if (!contEnd(_name, ".bin"))
//			_name += ".bin";
//		const char* fname = _name.c_str();
//		ofstream file;
//		file.open(fname);
//		file.close();
//	}
//};

class loadMazeCommand : public command
{
public:
	loadMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
	void execute()
	{
		int name_len = 0;
		in_file.read((char*)&name_len, sizeof(int));
		_name = new char[name_len + 1];

		if (_name == nullptr)
			throw "bad memory allocation";

		in_file.read(_name, name_len);
		_name[name_len] = '\0';
		vector<char> mymaze;
		for (int i = 0; in_file != EOF; i++)
			in_file.read((vector<char>) & mymaze[i], sizeof(vector<char>));
		vector<vector<int>> unmaze = uncompress(mymaze);

	}

private:
	ifstream& in_file;
	string _name;
	maze* _myMaze;
};