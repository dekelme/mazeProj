//#include<iostream>
//#include<algorithm>
//#include<vector>
//#include<string>
//#include<cstdlib>
//#include<time.h>
//#include<stack>
//#include<random>
//#include <queue>
////#include <Windows.h>
//#include<stdio.h>
//#include "dirent.h"
//#include<sys/stat.h>
//#include<stdlib.h>
//#include<fstream>
//#include"generator.h"
//
//
//using namespace std;
//
//class solution {};
//
//class searcher  /*public myAlgorithem*/ {
//public:
//	searcher() {}
//	virtual solution search(const searchable& sol) = 0;
//	virtual int getNumberOfEvaluated() = 0;
//	~searcher() {}
//};
//
//class commonSearcher : public searcher {
//public:
//	commonSearcher() {}
//	~commonSearcher() {}
//	virtual solution search(const searchable& sol) = 0;
//	virtual int getNumberOfEvaluated() {}						// need to build
//protected:
//	int _evaluatedNodes;
//	priority_queue <state> _openList;
//};
//
//class position {
//public:
//	position() = default;
//	~position() {}
//	virtual position* getPosition()const = 0;
//	virtual int getPos_x()const = 0;
//	virtual int getPos_y()const = 0;
//	virtual void setPosition(const position& pos) = 0;
//};
//
//class position2d : public position {
//private:
//	int _pos_x;
//	int _pos_y;
//public:
//	position2d() :position(), _pos_x(0), _pos_y(0) {}
//	position2d(const position& pos) {
//		_pos_x = pos.getPos_x();
//		_pos_y = pos.getPos_y();
//	}
//	position2d(const state& sta) { position2d(sta._pos); }
//	position2d(int x, int y) {
//		_pos_x = x;
//		_pos_y = y;
//	}
//	position* getPosition() { return this; }
//	int getPos_x() { return _pos_x; }
//	int getPos_y() { return _pos_y; }
//	void setPosition(const position& pos) {
//		_pos_x = pos.getPos_x();
//		_pos_y = pos.getPos_y();
//	}
//	~position2d() {}
//};
//
//class state {
//private:
//	position* _pos;
//public:
//	state() {}
//	~state() {}
//	bool operator==(state a)
//	{
//		if (_pos == a._pos)
//			return true;
//		else
//			return false;
//	}
//};
//
//class mazeInterface {
//private:
//public:
//	mazeInterface() {}
//	~mazeInterface() {}
//};
//
//class maze : public mazeInterface {
//private:
//	string _mazeName;
//	position* _entry;
//	position* _exit;
//	int** _data;
//	bool _isSolved;
//	state* _currState;
//	//formatMazeData()
//public:
//	maze() {}
//	void setSolved(bool isSolved) {}
//	position* getEntry() { return _entry; }
//	position* getEnd() { return _exit; }
//	state* posibleMoves() {}
//	~maze() {}
//};
//
//class searchable {
//private:
//public:
//	searchable() {}
//	virtual state& getEntry() const = 0;
//	virtual state& getEnd() const = 0;
//	~searchable() {}
//};
//
//class mazeSearchable : public searchable {
//private:
//public:
//	mazeSearchable() = default;
//	virtual state& getEntry() const
//	{
//
//	}
//	virtual state& getEnd() const
//	{
//
//	}
//	~mazeSearchable() {}
//};
//
//class BFS : public commonSearcher
//{
//public:
//	BFS() {};
//	~BFS() = default;
//
//	virtual solution search(const mazeSearchable& search)
//	{
//		state end = search.getEnd();
//		_openList.push(search.getEntry());		//push first node
//
//		while (!_openList.empty())
//		{
//			state curState = _openList.top();
//			if (curState == end)
//				break;
//			state neighbors = curState;//����� ������ ����� ������ ����
//			for (auto i = 0; i < neighbors.size(); ++i)
//			{
//				neighbors[i].visite = true;
//				neighbors[i].parent = curState;
//				_openList.push(neighbors[i]);
//			}
//		}
//
//	}
//
//
//private:
//	//state _start;
//	//state _end;
//	//mazeSearchable _searchable;
//};
//
//class Astar : public commonSearcher {
//public:
//    Astar() {}
//    ~Astar() {}
//	virtual solution search(const mazeSearchable& search)
//	{
//		state* current;
//		state* childrens[4];
//		int cost[4];
//		int tempGScore;
//		auto iterator = search.getEnd();
//
//
//		/*search.start->g = 0;*/
//		/*push(search.getEntry();*/
//		make_heap(search.getEntry(), search.getEnd(), CompareMin);
//		while (!_openList.empty())
//		{
//			pop_heap(search.getEntry(), search.getEnd(), CompareMin);
//			/*current = search.back();*/
//
//			if (current == search.getEnd()) {
//				return ;
//			}
//
//			search.pop_back();
//			current->visited = true;
//
//			childrens[0] = current->top;
//			childrens[1] = current->bottom;
//			childrens[2] = current->left;
//			childrens[3] = current->right;
//
//			cost[0] = current->tcost;
//			cost[1] = current->bcost;
//			cost[2] = current->lcost;
//			cost[3] = current->rcost;
//
//			for (int i = 0; i < 4; i++) 
//			{
//				if (childrens[i] && !childrens[i]->visited) 
//				{
//					iterator = find(search.getEntry(), search.getEnd(), childrens[i]);
//					if (iterator == search.getEnd())
//					{
//						search.push_back(childrens[i]);
//						push_heap(search.getEntry(), search.getEnd(), CompareMin);
//					}
//					tempGScore = current->g + cost[i];
//					if (tempGScore < childrens[i]->g) 
//					{
//						childrens[i]->g = tempGScore;
//						childrens[i]->previous = current;
//						make_heap(search.getEntry(), search.getEnd(), CompareMin);
//					}
//
//				}
//			}
//		}
//		return ;
//	}
//};
//
//class controller {
//public:
//	controller(maze myMaze) {
//		m_commands[dir] = new mazecommand(myMaze);
//	}
//	command* get(const string& command)
//	{
//		auto it = m_commands.find(command);
//		if (it == m_commands.end())
//			return nullptr;
//
//		return it->second;
//	}
//	//function<void()>* getF(const string& command)
//	//{
//	//	auto it = m_functions.find(command);
//	//	if (it == m_functions.end())
//	//		return nullptr;
//
//	//	return &(it->second);
//	//}
//	~controller() {}
//private:
//	map<string, Command*> m_commands;
//	/*map<string, function<void()> > m_functions;*/
//};
//
//class command {
//public:
//	virtual void execute() = 0;
//	bool contEnd(string str, string end)
//	{
//		if (str.length() >= end.length())
//			return (0 == str.compare(str.length() - end.length(), end.length(), end));
//		else
//			return false;
//	}
//};
//
//class generateMazeCommand : public command {
//private:
//	maze _myMaze;
//	string _name;
//	int _size;
//	myMaze2dGenerator _generate;
//public:
//	generateMazeCommand(const maze& mymaze, string name, int size) : _myMaze(mymaze), _name(name), _size(size) {}
//	void execute()
//	{
//		_myMaze = _generate.generate(_size);
//		cout << "Maze " << _name << "is ready" << endl;
//	}
//};
//
////class dirCommand : public command {
////private:
////	maze* _myMaze;
////	FILE* _mazeFile;
////public:
////	dirCommand(maze mymaze, ) : _myMaze(mymaze) {}
////	void execute()
////	{
////		char filename[] = "test.txt";
////		char fullFilename[MAX_PATH];
////
////		GetFullPathName(_mazeFile, MAX_PATH, fullFilename, nullptr);
////	}
////};
//class dirCommand : public command
//{
//private:
//
//public:
//	dirCommand();
//	~dirCommand();
//
//	void execute(char* dir_name) {
//		DIR* _dir;
//		struct dirent* dire;
//		struct stat sta;
//		_dir = opendir(dir_name);
//		if (!_dir) {
//			cout << "Not found" << endl;
//		}
//		while ((dire = readdir(_dir)) != NULL)
//		{
//			if (dire->d_name[0] != '.') {
//				string path = string(dir_name) + "/" + string(dire->d_name);
//				cout << path << endl;
//				stat(path.c_str(), &sta);
//				if (S_ISDIR(sta.st_mode)) {
//					execute((char*)path.c_str());
//				}
//			}
//		}
//		closedir(_dir);
//	}
//};
//
//class mazeCompression 
//{
//private:
//public:
//};
//
//class displayCommand : public command {
//private:
//	maze _myMaze;
//	string _name;
//	Maze2dGenerator* _print;
//public:
//	displayCommand(const maze& mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		cout << _name << endl;
//		_print.print();
//	}
//};
//
//class saveMazeCommand : public command
//{
//private:
//	maze* _myMaze;
//	string _name;
//public:
//	saveMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		if (!contEnd(_name, ".bin"))
//			_name += ".bin";
//		const char* fname = _name.c_str();
//		ofstream file;
//		file.open(fname);
//		file.close();
//	}
//};
//
//class loadMazeCommand : public command
//{
//public:
//	loadMazeCommand (maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute(string name)
//	{
//		char d;
//		if (!contEnd(_name, ".bin"))
//			_name += ".bin";
//		const char* fname = name.c_str();
//		ifstream file;
//		file.open(fname);
//		file >> _load;
//		file.close();
//
//	}
//
//private:
//	maze* _myMaze;
//	string _name;
//	char _load;
//};
//
//#include "c_plus_plus_serializer.h"
//
//class formateMazeData
//{
//	public:
//		int a;
//		string b;
//		vector <string> c;
//
//		friend ostream& operator<<(ostream& out, cell my)
//		{
//			out << bits(my.t.a) << bits(my.t.b) << bits(my.t.c);
//			return (out);
//		}
//
//		friend istream& operator>>(istream& in, cell my)
//		{
//			in >> bits(my.t.a) >> bits(my.t.b) >> bits(my.t.c);
//			return (in);
//		}
//
//		friend ostream& operator<<(ostream& out,
//			class formateMazeData& my)
//		{
//			out << "a:" << my.a << " b:" << my.b;
//
//			out << " c:[" << my.c.size() << " elems]:";
//			for (auto v : my.c) {
//				out << v << " ";
//			}
//			out << endl;
//
//			return (out);
//		}
//
//
//	static void save_map_key_string_value_custom(const string filename)
//	{
//		cout << "save to " << filename << endl;
//		ofstream out(filename, ios::binary);
//
//		map< string, class formateMazeData > m;
//
//		auto c1 = formateMazeData();
//		c1.a = 1;
//		c1.b = "hello";
//		initializer_list L1 = { "vec-elem1", "vec-elem2" };
//		vector l1(L1);
//		c1.c = l1;
//
//		auto c2 = formateMazeData();
//		c2.a = 2;
//		c2.b = "there";
//		initializer_list L2 = { "vec-elem3", "vec-elem4" };
//		vector l2(L2);
//		c2.c = l2;
//
//		m.insert(make_pair(string("key1"), c1));
//		m.insert(make_pair(string("key2"), c2));
//
//		out << bits(m);
//	}
//
//	static void load_map_key_string_value_custom(const string filename)
//	{
//		cout << "read from " << filename << endl;
//		ifstream in(filename);
//
//		map< string, class formateMazeData > m;
//
//		in >> bits(m);
//		cout << endl;
//
//		cout << "m = " << m.size() << " list-elems { " << endl;
//		for (auto i : m) {
//			cout << "    [" << i.first << "] = " << i.second;
//		}
//		cout << "}" << endl;
//	}
//
//	void map_custom_class_example(void)
//	{
//		cout << "map key string, value class" << endl;
//		cout << "============================" << endl;
//		save_map_key_string_value_custom(string("map_of_custom_class.bin"));
//		load_map_key_string_value_custom(string("map_of_custom_class.bin"));
//		cout << endl;
//	}
//
//
//
//
//
//
//	//formateMazeData(){}
//	////Create a new AMEF object
//	//formateMazeData* object = new formateMazeData();
//
//	////Add a child string object
//	//objectaddPacket("This is the Automated Message Exchange Format Object property!!", "adasd");
//
//	////Add a child integer object
//	//object->addPacket(21213);
//
//	////Add a child boolean object
//	//object->addPacket(true);
//
//	//formateMazeData* object2 = new formateMazeData();
//	//string j = "This is the property of a nested Automated Message Exchange Format Object";
//	//object2->addPacket(j);
//	//object2->addPacket(134123);
//	//object2->addPacket(false);
//
//	////Add a child character object
//	//object2->addPacket('d');
//
//	////Add a child AMEF Object
//	//object->addPacket(object2);
//
//	////Encode the AMEF obejct
//	//string str = new formateMazeData()->encode(object, false);
//
//
//
//	/*formateMazeData(maze* mymaze, char* compMaze) : _myMaze(mymaze), _compMaze(compMzae) {}
//	void execute(maze* mymaze)
//	{
//		for (int i = 0; i < ; i++)
//			[i] = 0;
//
//		for (int x = 0; x < size; x++)
//			for (int y = 0; y < size; y++)
//				_myMaze[(size * x) + (y + 1)] = _myMaze->getPosition(x, y);
//
//		int count = 0, int k = 0;
//		for (int i = 0, k = 0; i < size; i++, k++)
//		{
//			if (_myMaze[i] == 'S')
//				_myMaze[k] = 'S';
//			else if (tmp_maze[i] == 'G')
//				_myMaze[k] = 'G';
//			else if (_myMaze[i] == '0')
//			{
//				_myMaze[k] = '0';
//				k++;
//				while (tmp_maze[i++] == '0')
//					count++;
//				_myMaze[k] = count;
//				count = 0;
//			}
//			else if (_myMaze[i] == '1')
//			{
//				_myMaze[k] = '1';
//				k++;
//				while (_myMaze[i++] == '1')
//					count++;
//				_myMaze[k] = count;
//			}
//		}
//
//		
//
//	}
//private:
//	char* _compMaze;
//	maze _myMaze;*/
//};
//
//vector<int> formateMazeData ()
//{
//	vector<int> all;
//	all.push_back(_start.getPos_x());
//	all.push_back(_start.getPos_y());
//	all.push_back(_end.getPos_x());
//	all.push_back(_end.getPos_y());
//	all.push_back(y);
//	all.push_back(x);
//
//	int count = 0, 
//
//	vector <char> tmp;
//
//	for (int i = 0; i < y; i++) 
//	{
//		for (int j = 0; j < x; j++)
//			tmp.push_back(_maze[i][j]);
//	}
//
//	for (int i = 0; i < tmp.size(); i++) 
//	{
//		if (tmp[i] == 'S')
//			continue;
//		else if (tmp[i] == 'E')
//			continue;
//		else if (tmp[i] == '0')
//		{
//			all.push_back(0);
//			while (tmp[i++] == '0' && i < tmp.size())
//			{
//				if (tmp[i] == '0')
//					count++;
//				else if (tmp[i] == 'E')
//				{
//					all.push_back(count);
//					count = 0;
//					i++;
//			}
//			else if (tmp[i] == 'S') 
//			{
//				all.push_back(count);
//				count = 0;
//				i++;
//			}
//			else if (tmp[i] == '1')
//			{
//				all.push_back(count);
//				count = 0;
//				all.push_back(1);
//			}
//		}
//		all.push_back(count);
//		count = 0;
//	}
//	else if (tmp[i] == '1') 
//	{
//		all.push_back(1);
//		while (tmp[i++] == '1' && i < tmp.size()) 
//		{
//			if (tmp[i] == '1')
//				count++;
//			else if (tmp[i] == 'E') 
//			{
//				all.push_back(count);
//				count = 0;
//				i++;
//			}
//			else if (tmp[i] == 'S') 
//			{
//				all.push_back(count);
//				count = 0;
//				i++;
//			}
//			else if (tmp[i] == '0') 
//			{
//				all.push_back(count);
//				count = 0;
//				all.push_back(0);
//			}
//		}
//		all.push_back(count);
//		count = 0;
//	}
//
//	}
//	return all;
//}
//
////class Demo 
////{
////public:
////	Demo(Maze2dGenerator demo) : _demo(demo) {}
////	~Demo(){}
////	void run()
////	{
////		Maze2d demoMaze = _demo.generate('demo', 10);
////		demoMaze.print();
////		solution sol = search();
////	}
////private:
////	myMaze2dGenerator _demo;
////};