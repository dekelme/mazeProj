//#pragma once
//#include<iostream>
//#include<vector>
//
//using namespace std;
//class cell;
//
//class Position
//{
//public:
//	Position(const cell* pos);
//	Position(int y = 0, int x = 0) : _pos(y, x) {};
//	Position(const Position& p) : _pos(p._pos) {};
//	Position(pair<int, int> pos) : _pos(pos) {};
//	
//
//	~Position() = default;
//	int getPos_x()const { return _pos.second; };
//	int getPos_y()const { return _pos.first; };
//	pair<int, int> getPosition()const { return _pos; };
//	friend ostream& operator<<(ostream& output, const Position& pos);
//	void setPos_x(int x) { _pos.second = x; };
//	void setPos_y(int y) { _pos.first = y; };
//	bool operator ==(const Position& other)const;
//private:
//	pair<int, int> _pos;
//};
//
//class cell
//{
//public:
//	cell(int x = 0, int y = 0) : _top(true), _right(true), _bottom(true), _left(true), _visited(false), _position(y, x), _sol(false) {};
//	cell(const cell& a) :_top(a._top), _right(a._right), _bottom(a._bottom), _left(a._left), _visited(a._visited), _position(a._position), _sol(false) {};
//	cell(const cell* a) :_top(a->_top), _right(a->_right), _bottom(a->_bottom), _left(a->_left), _visited(a->_visited), _position(a->_position), _sol(false) {};
//	~cell() = default;
//	bool isVisited() const { return _visited; };
//	void setVisited(bool state) { _visited = state; };
//	Position getPos()const { return _position; };
//	vector<pair<int, int>> getAdjacents()const { return _adjacent; };
//	bool operator ==(const cell& other)const
//	{
//		return _position == other.getPos();
//	}
//	void setPos(int y, int x);
//	void setAdjencts();
//	bool getWall(string str) const;
//	void removeWall(string str);
//	void partOfSolution()
//	{
//		_sol = true;
//	}
//	bool inSolution() { return _sol; };
//
//private:
//	bool _top;
//	bool _right;
//	bool _bottom;
//	bool _left;
//	bool _visited;
//	bool _sol;
//	vector<pair<int, int>> _adjacent;
//	Position _position;
//};




#pragma once
#include<iostream>
#include<vector>
#include<string>


using namespace std;
class cell;

class Position
{
public:
	Position(const cell* pos);
	Position(int y = 0, int x = 0) : _pos(y, x) {};
	Position(const Position& p) : _pos(p._pos) {};
	Position(pair<int, int> pos) : _pos(pos) {};


	~Position() = default;
	int getPos_x()const { return _pos.second; };
	int getPos_y()const { return _pos.first; };
	pair<int, int> getPosition()const { return _pos; };
	friend ostream& operator<<(ostream& output, const Position& pos);
	void setPos_x(int x) { _pos.second = x; };
	void setPos_y(int y) { _pos.first = y; };
	bool operator ==(const Position& other)const;
	bool operator<(const Position& other)const
	{

		string one = to_string(this->_pos.first) + to_string(this->_pos.second);
		string two = to_string(other._pos.first) + to_string(other._pos.second);
		bool ans = one < two;
		return ans;
	}
private:
	pair<int, int> _pos;
};

class cell
{
public:
	cell(int x = 0, int y = 0) : _top(true), _right(true), _bottom(true), _left(true), _visited(false), _position(y, x) {};
	cell(const cell& a) :_top(a._top), _right(a._right), _bottom(a._bottom), _left(a._left), _visited(a._visited), _position(a._position) {};
	cell(const cell* a) :_top(a->_top), _right(a->_right), _bottom(a->_bottom), _left(a->_left), _visited(a->_visited), _position(a->_position){};
	~cell() = default;
	bool isVisited() const { return _visited; };
	void setVisited(bool state) { _visited = state; };
	Position getPos()const { return _position; };
	vector<pair<int, int>> getAdjacents()const { return _adjacent; };
	bool operator ==(const cell& other)const
	{
		return _position == other.getPos();
	}
	void setPos(int y, int x);
	void setAdjencts();
	bool getWall(string str) const;
	void removeWall(string str);
	//void partOfSolution()
	//{
	//	_sol = true;
	//}
	//bool inSolution() { return _sol; };

private:
	//bool _sol;
	bool _top;
	bool _right;
	bool _bottom;
	bool _left;
	
	bool _visited;
	vector<pair<int, int>> _adjacent;
	Position _position;
};