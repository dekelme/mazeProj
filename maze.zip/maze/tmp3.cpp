//#include<iostream>
//#include<algorithm>
//#include<vector>
//#include<string>
//#include<cstdlib>
//#include<time.h>
//#include<stack>
//#include<random>
//#include <queue>
//#include<stdio.h>
//#include"dirent.h"
//#include<sys/stat.h>
//#include<stdlib.h>
//#include<fstream>
//#include<map>
//#include"maze.h"
//
//
//using namespace std;
//
//template<class type>
//class Solution
//{
//public:
//	Solution() = default;
//	~Solution()
//	{
//		int size = _solution.size();
//		for (int i = 0; i < size; i++)
//		{
//			delete _solution[i];
//		}
//	}
//
//	void pushState(type a)
//	{
//		_solution.insert(_solution.begin(), a);
//	}
//	vector<type> getSolution()const { return _solution; };
//
//private:
//	vector<type> _solution;
//};
//
//
//template<class type>
//class searcher
//{
//public:
//	searcher() {}
//	virtual Solution<type> search(const searchable* sol) = 0;
//	virtual int getNumberOfEvaluated() = 0;
//	~searcher() {}
//};
//
//
//template<class type>
//class commonSearcher : public searcher<type> {
//public:
//	commonSearcher() : _evaluatedNodes(0) {};
//	~commonSearcher() {}
//	virtual Solution<type> search(const searchable* sol) = 0;
//	virtual int getNumberOfEvaluated() {}						// need to build
//protected:
//	int _evaluatedNodes;
//	priority_queue <type*> _openList;
//};
//
//
//template< class type>
//class state {
//public:
//	state(type pos) : _state(pos), _cost(0), _cameFrom(nullptr) {};
//	state(const state* pos)
//	{
//		type tmp = pos->_state;
//		_state = tmp.getPosition();
//	}
//	~state() {}
//
//	double getStateCost()const { return _cost; };
//	type& getState()const { return _state; };
//
//	void setPrev(state* prev)
//	{
//		_cameFrom = prev;
//	}
//
//	bool operator==(state& other)
//	{
//		if (_state == other._state)
//			return true;
//
//		return false;
//
//		other._state;
//	}
//
//
//protected:
//	void setState(type state) { _state = state; };
//	type _state;
//	double _cost;
//	state* _cameFrom;
//};
//
//class mazeState : public state<cell>
//{
//public:
//	mazeState(cell pos) : state(pos) {};
//	mazeState(const cell* pos) : state(*pos) {};
//	mazeState(string str, cell pos) : state(pos)
//	{
//
//		Position tmp = pos.getPos();
//
//		int x = tmp.getPos_x();
//		int y = tmp.getPos_y();
//
//		if (str == "UP")
//			this->setState((y - 1, x));
//
//		if (str == "RIGHT")
//			this->setState((y, x + 1));
//
//		if (str == "DOWN")
//			this->setState((y + 1, x));
//
//		if (str == "LEFT")
//			this->setState((y, x - 1));
//
//	}
//	mazeState(const mazeState* pos) : state(pos) {};
//	bool operator <(const mazeState& other) { return _cost < other._cost; };
//	~mazeState() {};
//
//	void calculateCost(double stepCost, mazeState* from)
//	{
//		if (from == nullptr)
//			_cost = 0;
//		else
//			_cost = from->_cost;
//	}
//
//	//mazeState& pickBetter(mazeState& other)			// if equal we get other
//	//{
//	//	if (_cost < other._cost)
//	//		return *this;
//
//	//	return other;
//	//}
//};
//
//
//
//
//template<class type>
//class searchable {
//private:
//public:
//	searchable() = default;
//	~searchable() {}
//	virtual const type& getStartState() const = 0;
//	virtual const type& getGoalState() const = 0;
//	virtual vector<type> getAllPossibleStates(type& curr) = 0;
//};
//
//
//template<class type>
//class mazeSearchable : public searchable<type>
//{
//public:
//	mazeSearchable(maze2d maze) :searchable(), _maze(maze), _start(nullptr), _end(nullptr)
//	{
//		_start = new mazeState(_maze.getStartPosition());
//		_end = new mazeState(_maze.getStartPosition());
//		_stepCost = 10;
//	};
//
//	~mazeSearchable()
//	{
//		delete _start;
//		delete _end;
//	}
//
//	virtual const type& getStartState()const
//	{
//		return *_start;
//	}
//
//	virtual const type& getGoalState() const
//	{
//		return *_end;
//	}
//
//	virtual vector<type*> getAllPossibleStates(const type& curr)const
//	{
//		cell pos = curr.getState();
//
//		vector<mazeState*> vec;
//		vector<string> moves;
//		moves = _maze.getpossibleMoves(pos.getPos());
//
//		while (!moves.empty())
//		{
//			string tmp = moves.back();
//			moves.pop_back();
//
//			vec.push_back(new mazeState(tmp, pos));
//		}
//
//		return vec;
//	}
//
//	double getStepCost()const { return _stepCost; };
//
//private:
//	maze2d _maze;
//	double _stepCost;
//	type* _start;
//	type* _end;
//};
//
//
//template<class type>
//class BFS : public commonSearcher<type>
//{
//public:
//	BFS() {};
//	~BFS() = default;
//
//	virtual Solution<type> search(const mazeSearchable* ms)
//	{
//		type end = ms->getGoalState();
//		type* start = new type(ms->getStartState());
//		double cost = ms->getStepCost();
//
//		start->calculateCost(cost, nullptr);
//
//		_openList.push(start);												//push first node
//
//		while (!_openList.empty())
//		{
//			type* curState = _openList.top();
//			curState->getState().setVisited();
//			_evaluatedNodes++;
//
//			if (*curState == end)
//			{
//
//			}
//
//			vector<type*> tmp = ms->getAllPossibleStates(curState);		// get next possible states
//
//			for (int i = 0; i < tmp.size(); i++)
//			{
//				tmp[i]->setPrev(curState);
//				tmp[i]->calculateCost(cost, curState);
//				_openList.push(tmp[i]);
//			}
//		}
//	}
//};
//
//
//
////class Astar : public commonSearcher {
////public:
////    Astar() {}
////    ~Astar() {}
////	virtual solution search(const mazeSearchable& search)
////	{
////		state* current;
////		state* childrens[4];
////		int cost[4];
////		int tempGScore;
////		auto iterator = search.getEnd();
////
////
////		/*search.start->g = 0;*/
////		/*push(search.getEntry();*/
////		make_heap(search.getEntry(), search.getEnd(), CompareMin);
////		while (!_openList.empty())
////		{
////			pop_heap(search.getEntry(), search.getEnd(), CompareMin);
////			/*current = search.back();*/
////
////			if (current == search.getEnd()) {
////				return ;
////			}
////
////			search.pop_back();
////			current->visited = true;
////
////			childrens[0] = current->top;
////			childrens[1] = current->bottom;
////			childrens[2] = current->left;
////			childrens[3] = current->right;
////
////			cost[0] = current->tcost;
////			cost[1] = current->bcost;
////			cost[2] = current->lcost;
////			cost[3] = current->rcost;
////
////			for (int i = 0; i < 4; i++) 
////			{
////				if (childrens[i] && !childrens[i]->visited) 
////				{
////					iterator = find(search.getEntry(), search.getEnd(), childrens[i]);
////					if (iterator == search.getEnd())
////					{
////						search.push_back(childrens[i]);
////						push_heap(search.getEntry(), search.getEnd(), CompareMin);
////					}
////					tempGScore = current->g + cost[i];
////					if (tempGScore < childrens[i]->g) 
////					{
////						childrens[i]->g = tempGScore;
////						childrens[i]->previous = current;
////						std::make_heap(search.getEntry(), search.getEnd(), CompareMin);
////					}
////
////				}
////			}
////		}
////		return ;
////	}
////};
//
////class controller {
////public:
////	controller(maze myMaze) {
////		m_commands[dir] = new mazecommand(myMaze);
////	}
////	command* get(const string& command)
////	{
////		auto it = m_commands.find(command);
////		if (it == m_commands.end())
////			return nullptr;
////
////		return it->second;
////	}
////
////	~controller() {}
////private:
////	map<string, Command*> m_commands;
////};
//
////class command {
////public:
////	virtual void execute() = 0;
////};
//
////class generateMazeCommand : public command {
////private:
////	maze _myMaze;
////	string _name;
////	int _size;
////	myMaze2dGenerator _generate;
////public:
////	generateMazeCommand(const maze& mymaze, string name, int size) : _myMaze(mymaze), _name(name), _size(size) {}
////	void execute()
////	{
////		_myMaze = _generate.generate(_size);
////		cout << "Maze " << _name << "is ready" << endl;
////	}
////};
//
//
////class dirCommand : public command
////{
////private:
////
////public:
////	dirCommand();
////	~dirCommand();
////
////	void execute(char* dir_name) {
////		DIR* _dir;
////		struct dirent* dire;
////		struct stat sta;
////		_dir = opendir(dir_name);
////		if (!_dir) {
////			cout << "Not found" << endl;
////		}
////		while ((dire = readdir(_dir)) != NULL)
////		{
////			if (dire->d_name[0] != '.') {
////				string path = string(dir_name) + "/" + string(dire->d_name);
////				cout << path << endl;
////				stat(path.c_str(), &sta);
////				if (S_ISDIR(sta.st_mode)) {
////					execute((char*)path.c_str());
////				}
////			}
////		}
////		closedir(_dir);
////	}
////};
////
////class mazeCompression 
////{
////private:
////public:
////};
////
////
////class displayCommand : public command {
////private:
////	maze _myMaze;
////	string _name;
////	Maze2dGenerator* _print;
////public:
////	displayCommand(const maze& mymaze, string name) : _myMaze(mymaze), _name(name) {}
////	void execute()
////	{
////		cout << _name << endl;
////		_print.print();
////	}
////};
////
////class saveMazeCommand : public command {
////private:
////	maze* _myMaze;
////	string _name;
////public:
////	saveMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
////	void execute()
////	{
////		if (!contEnd(_name, ".txt"))
////			_name += ".txt";
////		const char* fname = _name.c_str();
////		ofstream file;
////		file.open(fname);
////		file.close();
////	}
////	bool contEnd(string str, string end)
////	{
////		if (str.length() >= end.length())
////			return (0 == str.compare(str.length() - end.length(), end.length(), end));
////		else
////			return false;
////	}
////};
////
//
//
