#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<stack>
#include"cell.h"
#include"state.h"


template<class type>
class Maze
{
public:
	Maze(type* start, type* end, string name) : _start(start), _end(end), _isSolved(false), _mazeName(name){};
	~Maze() = default;
	void setSolved(bool isSolved) { _isSolved = true; };
	type* getStartPosition()const{ return _start; }
	type* getGoalPosition()const{ return _end; }
	void setName(string name) { _mazeName = name; };
	virtual vector<string> getPossibleMoves(Position pos)const = 0;

protected:
	bool _isSolved;
	type* _start;
	type* _end;
	string _mazeName;
};


class Maze2d : public Maze<cell>
{
public:
	Maze2d(vector<vector<cell>> maze, string name, cell* start, cell* end);
	Maze2d(vector<vector<int>> maze, string name);
	~Maze2d() {};
	virtual vector<string> getPossibleMoves(Position pos)const;
	cell* getCell(Position pos)
	{
		return &_maze[pos.getPos_y()][pos.getPos_x()];
	}
	vector<int> formatMazeData();
	void print(vector<mazeState>* s = nullptr);

	cell* findCell(string str, const cell* curr)
	{
		Position tmp = curr->getPos();
		

		int x = tmp.getPos_x();
		int y = tmp.getPos_y();

		if (str == "UP")
			return &_maze[tmp.getPos_y()-1][tmp.getPos_x()];

		if (str == "RIGHT")
			return &_maze[tmp.getPos_y()][tmp.getPos_x() + 1];

		if (str == "DOWN")
			return &_maze[tmp.getPos_y()+1][tmp.getPos_x()];

		if (str == "LEFT")
			return &_maze[tmp.getPos_y()][tmp.getPos_x()-1];
	}

private:
	vector<vector<cell>> _maze;
};
