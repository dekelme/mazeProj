//#pragma once
//#include"searcher.h"
//#include <cmath>
//#include <map>
//
//
//template<class type>
//class heuristic
//{
//public:
//	heuristic() = default;
//	~heuristic() = default;
//	virtual double calculate(type* curr, type* goal, double step_cost) = 0;
//};
//
//
//void myprint(priority_queue<mazeState<cell>*> t)
//{
//	cout << "nodes in open list:" << endl;
//	for (int i = 0; i < t.size(); i++)
//	{
//		cout << t.top()->getState()->getPos() << " " << t.top()->getState_Gcost() << " " << t.top()->getState_h_cost() << endl;
//		t.pop();
//	}
//}
//
//
//class MazeAirDistance : public heuristic<mazeState<cell>>
//{
//public:
//	MazeAirDistance() = default;
//	~MazeAirDistance() = default;
//	virtual double calculate(mazeState<cell>* curr, mazeState<cell>* goal, double step_cost)
//	{
//		pair<int, int> from = curr->getState()->getPos().getPosition();
//		pair<int, int> to = goal->getState()->getPos().getPosition();
//
//		int row_d = to.first - from.first;
//		int col_d = to.second - from.second;
//
//		double ans = sqrt(double(pow(double(row_d), 2) + pow(double(col_d), 2)));
//
//		return ans * step_cost ;
//	}
//
//};
//
//
//class MazeManheten : public heuristic<mazeState<cell>>
//{
//public:
//	MazeManheten() = default;
//	~MazeManheten() = default;
//	virtual double calculate(mazeState<cell>* curr, mazeState<cell>* goal, double step_cost)
//	{
//		pair<int, int> from = curr->getState()->getPos().getPosition();
//		pair<int, int> to = goal->getState()->getPos().getPosition();
//
//		int row_d = to.first - from.first;
//		int col_d = to.second - from.second;
//
//		int ans = row_d + col_d;
//		return (double)ans * step_cost ;
//	}
//
//};
//
//
//
//class Astar : public commonSearcher<mazeState<cell>>
//{
//public:
//	Astar(heuristic< mazeState<cell>>* h = nullptr) : commonSearcher<mazeState<cell>>(), _h(h) {};
//	~Astar()
//	{
//		delete _h;
//	}
//
//	void setHuristic(heuristic< mazeState<cell>>* h)
//	{
//		delete _h;
//		_h = h;
//	}
//
//	virtual Solution<mazeState<cell>> search(searchable<mazeState<cell>>* s)
//	{
//		while (!_openList.empty())
//			_openList.pop();
//
//		mazeSearchable* ms = dynamic_cast<mazeSearchable*>(s);
//		mazeState<cell> end = ms->getGoalState();
//		Position endPos = end.getState()->getPos();
//		Solution<mazeState<cell>> ans;
//
//		mazeState<cell>* start = new mazeState<cell>(ms->getStartState());
//
//		double stepCost = ms->getStepCost();
//		double h_cost = _h->calculate(start, &end , stepCost);										// calculate huristic cost
//		start->calculateCost(stepCost, start, h_cost);									// calculate cost
//
//		this->_openList.push(start);													// start in open liset
//		resetEnodes();
//
//		while (!this->_openList.empty())												// while open not empty
//		{
//			mazeState<cell>* curr = this->_openList.top();								// get best node
//			_openList.pop();
//			_evaluatedNodes++;
//
//			Position p = curr->getState()->getPos();
//	
//			//cout << endl;
//			//cout << "current node position: " << p << endl;
//			//cout << "current node g cost: " << curr->getState_Gcost() <<" and h cost: "<< curr->getState_h_cost()<<endl;
//
//			if (p == endPos)
//			{
//				while (curr != nullptr)
//				{
//					ans.pushState(*curr);
//					State<cell>* tmp = curr->getPrev();
//					curr = dynamic_cast<mazeState<cell>*>(tmp);
//				}
//				return ans;
//			}
//
//			vector<mazeState<cell>*> tmp = ms->getAllPossibleStates(curr);		// get next possible states
//
//			//cout << " possible states:" << endl;
//			//for (int i = 0; i < tmp.size(); i++)
//			//{
//			//	cout<<tmp[i]->getState()->getPos()<<" "<<  endl;
//			//}
//
//			for (int i = 0; i < (signed)tmp.size(); i++)
//			{
//				h_cost = _h->calculate(tmp[i], &end , stepCost);
//				tmp[i]->calculateCost(stepCost, curr, h_cost);
//
//				p = tmp[i]->getState()->getPos();
//				auto it = _openSeen.find(p);
//				if (it != _openSeen.end())
//				{
//					if (_openSeen[p] <= tmp[i]->getStateCost())
//					{
//						delete tmp[i];
//						continue;
//					}
//				}
//
//				it = _closedSeen.find(p);
//				if (it != _closedSeen.end())
//				{
//					if (_closedSeen[p] <= tmp[i]->getStateCost())
//					{
//						delete tmp[i];
//						continue;
//					}
//				}
//
//				tmp[i]->setPrev(curr);
//				this->_openList.push(tmp[i]);
//				_openSeen[p] = tmp[i]->getStateCost();
//			}
//
//			_closedSeen[curr->getState()->getPos()] = curr->getStateCost();				// remember pos and cost in closed
//			_openSeen.erase(curr->getState()->getPos());
//
//			myprint(_openList);
//			cout << endl;
//		}
//
//		return ans;
//	}
//
//private:
//	heuristic<mazeState<cell>>* _h;
//	map<Position, double> _openSeen;
//	map<Position, double> _closedSeen;
//
//};
//


#pragma once
#include"heuristic.h"





class Astar : public commonSearcher<mazeState>
{
public:
	Astar(heuristic< mazeState>* h = nullptr) : commonSearcher<mazeState>(), _h(h) {};
	~Astar()
	{
		delete _h;
	}

	void setHuristic(heuristic<mazeState>* h)
	{
		delete _h;
		_h = h;
	}

	virtual Solution<mazeState> search(searchable<mazeState>* s)
	{
		while (!_openList.empty())
			_openList.pop();

		_openSeen.clear();
		_closedSeen.clear();

		mazeSearchable* ms = dynamic_cast<mazeSearchable*>(s);
		mazeState end = ms->getGoalState();
		Position endPos = end.getState()->getPos();
		Solution<mazeState> ans;

		mazeState* start = new mazeState(ms->getStartState());

		double stepCost = ms->getStepCost();
		double h_cost = _h->calculate(start, &end, stepCost);										// calculate huristic cost
		start->calculateCost(stepCost, start, h_cost);									// calculate cost

		this->_openList.push(start);													// start in open liset
		resetEnodes();

		while (!this->_openList.empty())												// while open not empty
		{
			mazeState* curr = this->_openList.top();									// get best node
			_openList.pop();
			_evaluatedNodes++;

			Position p = curr->getState()->getPos();

			//cout << endl;
			//cout << "current node position: " << p << endl;
			//cout << "current node g cost: " << curr->getState_Gcost() << " and h cost: " << curr->getState_h_cost() << endl;

			if (p == endPos)
			{
				while (curr != nullptr)
				{
					ans.pushState(*curr);
					State<cell>* tmp = curr->getPrev();
					curr = dynamic_cast<mazeState*>(tmp);
				}
				return ans;
			}

			vector<mazeState*> tmp = ms->getAllPossibleStates(curr);		// get next possible states

			//cout << " possible states:" << endl;
			//for (int i = 0; i < tmp.size(); i++)
			//{
			//	cout<<tmp[i]->getState()->getPos()<<" "<<  endl;
			//}

			for (int i = 0; i < (signed)tmp.size(); i++)
			{
				h_cost = _h->calculate(tmp[i], &end, stepCost);
				tmp[i]->calculateCost(stepCost, curr, h_cost);

				p = tmp[i]->getState()->getPos();
				auto it = _openSeen.find(p);
				if (it != _openSeen.end())
				{
					if (_openSeen[p] < tmp[i]->getStateCost())
					{
						delete tmp[i];
						continue;
					}
				}

				it = _closedSeen.find(p);
				if (it != _closedSeen.end())
				{
					if (_closedSeen[p] < tmp[i]->getStateCost())
					{
						delete tmp[i];
						continue;
					}
				}

				tmp[i]->setPrev(curr);
				this->_openList.push(tmp[i]);
				_openSeen[p] = tmp[i]->getStateCost();
			}

			_closedSeen[curr->getState()->getPos()] = curr->getStateCost();				// remember pos and cost in closed
			_openSeen.erase(curr->getState()->getPos());

			//myprint(_openList);
			//cout << endl;
		}

		return ans;
	}

private:
	heuristic<mazeState>* _h;
	map<Position, double> _openSeen;
	map<Position, double> _closedSeen;

};

