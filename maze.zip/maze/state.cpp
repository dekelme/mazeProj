#pragma once
#include"state.h"
//
//
//template<class type>
//State<type>::State(type* state, State* prev, double cost) : _cameFrom(prev), _cost(cost) {};
//
//template<class type>
//State<type>::~State(){};
//
//template<class type>
//double State<type>::getStateCost()const { return  this->_cost; };
//
//template<class type>
//State<type>* State<type>::getPrev() { return this->_cameFrom; };
//
//template<class type>
//void State<type>::setPrev(State* prev) { this->_cameFrom = prev; };
//
//template<class type>
//bool State<type>::operator<(State* other)const { return this->_cost < other->_cost; };
//
//template<class type>
//type* State<type>::getState() { return this->_state; };
//
//
//
//
//
//// maze state         
//
//template<class type>
//mazeState<type>::mazeState( type* pos, State<type>* prev , double cost) :State(prev){};
//
//template<class type>
//mazeState<type>::~mazeState() {};
//
//	
//template<class type>
//void mazeState<type>::calculateCost(double stepCost, mazeState* from, double h_cost )
//{
//	if (from == this)
//		this->_cost = h_cost;		
//	else 
//		this->_cost = from->_cost + stepCost + h_cost;
//}
//
//
//template<class type>
//bool mazeState<type>::operator == (State<type>* other)const
//{
//	mazeState* tmp = dynamic_cast<mazeState*>(other);
//	if (this->_state == tmp->_state)
//		return true;
//
//	return false;
//}
//








// maze state         

mazeState::mazeState(cell* pos, State<cell>* prev, double cost) :State<cell>(pos, prev, cost) 
{
	/*validtion*/
	if (pos == nullptr || prev == nullptr)
		throw "Cell state Error";
	/*validtion*/
};


mazeState::~mazeState() {};


bool mazeState::operator<(State<cell>* other)const
{
	/*validtion*/
	if (other == nullptr)
		throw "Cell state Error";
	/*validtion*/

	cout << "left: " << this->_cost + this->_h_cost << " right: " << other->getStateCost()<< endl;
	if (this->_cost + this->_h_cost < other->getStateCost())
	{
		cout << "choose left" << endl;
		return true;
	}

	cout << "choose right" << endl;
	return false;
	return false;
};



void mazeState::calculateCost(double stepCost, mazeState* from, double h_cost)
{
	/*validtion*/
	if (from == nullptr)
		throw "Maze state Error";
	/*validtion*/
	this->_cost = 0;
	this->_h_cost = 0;
	if (from == this)
		this->_cost = 0;
	else
		this->_cost = from->_cost + stepCost;

	this->_h_cost = h_cost;
}



bool mazeState::operator == (State<cell>* other)const
{
	/*validtion*/
	if (other == nullptr)
		throw "Cell state Error";
	/*validtion*/
	mazeState* tmp = dynamic_cast<mazeState*>(other);
	if (this->_state == tmp->_state)
		return true;

	return false;
}
