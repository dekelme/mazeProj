#pragma once
#include"maze.h"
#include<map>

//     maze2d

Maze2d::Maze2d(vector<vector<cell>> maze, string name, cell* start, cell* end) : Maze(start, end,name)
{
	/*validtion*/
	if (start == nullptr || end == nullptr )
		throw "Cell state Error";
	/*validtion*/
	_maze = maze;
	_isSolved = false;
	_start = &_maze[start->getPos().getPos_y()][start->getPos().getPos_x()];
	_end = &_maze[end->getPos().getPos_y()][end->getPos().getPos_x()];

};



vector<string> Maze2d::getPossibleMoves(Position pos)const
{

	const cell* tmp = &_maze[pos.getPos_y()][pos.getPos_x()];
	bool t = tmp->getWall("top");
	bool r = tmp->getWall("right");
	bool b = tmp->getWall("bottom");
	bool l = tmp->getWall("left");

	vector<string> ans;

	if (!t)
		ans.push_back("UP");
	if (!r)
		ans.push_back("RIGHT");
	if (!b)
		ans.push_back("DOWN");
	if (!l)
		ans.push_back("LEFT");


	
	return ans;
}

vector<int> Maze2d::formatMazeData()
{
	vector<int> ans;
	ans.push_back(_maze.size());
	for (int i = 0; i < (signed)_maze.size(); i++)
	{
		for (int n = 0; n < (signed)_maze.size(); n++)
		{
			bool t = _maze[i][n].getWall("top");
			bool l = _maze[i][n].getWall("left");
			bool b = _maze[i][n].getWall("bottom");
			bool r = _maze[i][n].getWall("right");
			ans.push_back(t);
			ans.push_back(r);
			ans.push_back(b);
			ans.push_back(l);
		}
	}
	return ans;
}


void Maze2d::print(vector<mazeState>* s)
{
	/*validtion*/
	if (s == nullptr)
		throw "Maze state Error";
	/*validtion*/
	vector<Position> tmp;
	Position p;

	if (s)
	{
		for (int i = 0; i < (signed)s->size(); i++)
		{
			p = (*s)[i].getState()->getPos();
			tmp.push_back(p);
		}
	}

	vector<vector<char>> ans;
	int size = _maze.size();

	int size2 = size * 2 + 1;
	ans.resize(size2);


	for (int i = 0; i < size2; i++)
	{
		ans[i].resize(size2);
		fill(ans[i].begin(), ans[i].end(), 1);
	}

	char wall = 0;
	char free = 1;

	vector<Position>::iterator it;

	int a = 1;
	for (int i = 0; i < size; i++)
	{
		int b = 1;
		for (int j = 0; j < size; j++)
		{
			if (_maze[i][j].getWall("top"))
			{
				if (ans[a - 1][b - 1] == free)
					ans[a - 1][b - 1] = wall;

				if (ans[a - 1][b] == free)
					ans[a - 1][b] = wall;

				if (ans[a - 1][b + 1] == free)
					ans[a - 1][b + 1] = wall;
			}

			if (_maze[i][j].getWall("right"))
			{
				if (ans[a - 1][b + 1] == free)
					ans[a - 1][b + 1] = wall;

				if (ans[a][b + 1] == free)
					ans[a][b + 1] = wall;

				if (ans[a + 1][b + 1] == free)
					ans[a + 1][b + 1] = wall;
			}

			if (_maze[i][j].getWall("bottom"))
			{
				if (ans[a + 1][b - 1] == free)
					ans[a + 1][b - 1] = wall;

				if (ans[a + 1][b] == free)
					ans[a + 1][b] = wall;

				if (ans[a + 1][b + 1] == free)
					ans[a + 1][b + 1] = wall;
			}

			if (_maze[i][j].getWall("left"))
			{
				if (ans[a - 1][b - 1] == free)
					ans[a - 1][b - 1] = wall;

				if (ans[a][b - 1] == free)
					ans[a][b - 1] = wall;

				if (ans[a + 1][b - 1] == free)
					ans[a + 1][b - 1] = wall;
			}

			b += 2;
		}

		a += 2;
	}


	if (s)
	{
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				p = _maze[i][j].getPos();
				it = find(tmp.begin(), tmp.end(), p);
				if (it != tmp.end())
					ans[it->getPos_y() * 2 + 1][it->getPos_x() * 2 + 1] = 3;
			}
		}
	}


	p = _start->getPos();
	ans[p.getPos_y() * 2 + 1][p.getPos_x() * 2 + 1] = 4;

	p = _end->getPos();
	ans[p.getPos_y() * 2 + 1][p.getPos_x() * 2 + 1] = 5;

	//for (int i = 0; i < size; i++)
	//{
	//	if (i == 0)
	//		cout << "   ";
	//	cout << i << i << "  ";
	//}
	//cout << endl;

	int row = 0;
	for (int i = 0; i < size2; i++)
	{
		//if (i % 2 == 0)
		//	cout << " ";
		//else
		//	cout << row++;

		for (int j = 0; j < size2; j++)
		{
			if (ans[i][j] == 0)
				cout << "||";

			if (ans[i][j] == 1)
				cout << "  ";

			if (ans[i][j] == 3)
				cout << "++";

			if (ans[i][j] == 4)
				cout << "S ";

			if (ans[i][j] == 5)
				cout << "E ";
		}

		cout << endl;
	}
}




