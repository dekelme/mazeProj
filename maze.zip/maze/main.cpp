#pragma once
#include"cell.h"
#include"maze.h"
#include"state.h"
#include"Demo.h"


class Test
{
public:
    Test() = default;

    void testGenerator(Maze2dGenerator& mg)
    {
        cout << mg.measureAlgorithmTime(10,"jjj") << endl;

        Maze2d maze = mg.generate( 10, "jjj");

        Position p = maze.getStartPosition();
        Position p1 = maze.getGoalPosition();

        cout << "start position: " << p << endl;
        cout << "goal position: " << p1 << endl;

   
        //maze.print();
        vector<string> moves = maze.getPossibleMoves(p);

        cout << "possible directions: [ ";
        for (auto move : moves)
            cout << move << " ";
        cout << "]" << endl;

        moves = maze.getPossibleMoves(p1);

        cout << "possible directions: [ ";
        for (auto move : moves)
            cout << move << " ";
        cout << "]" << endl;


    }
};






//
//class CLI
//{
//public:
//    CLI(istream* in, ostream* out) : _in(in), _out(out) 
//	{
//		if (_in == nullptr || _out == nullptr)
//		{
//
//		}
//
//		_commands["dir"] = new dirCommand();
//		_commands["generate maze"] = new generateMazeCommand();
//		_commands["display"] = new displayCommand();
//		_commands["save maze"] = new saveMazeCommand();
//		_commands["load"] = new loadMazeCommand();
//		_commands["file size"] = new fileSizeCommand();
//		_commands["solve"] = new solveCommand();
//		_commands["display solution"] = new displayCommand();
//		_commands["exit"] = new exitCommand();
//	};
//    ~CLI();
//
//private:
//    istream* _in;
//    ostream* _out;
//	map<string, command*> _commands;
//};
//
//
//
//
//
//class command {
//public:
//	virtual void execute() = 0;
//};
//
//
//
//class exitCommand: public command
//{
//public:
//	exitCommand();
//	~exitCommand();
//	virtual void execute() {};
//private:
//
//};
//
//
//class displaySolutionCommand : public command
//{
//public:
//	displaySolutionCommand();
//	~displaySolutionCommand();
//	virtual void execute() {};
//private:
//
//};
//
//
//class solveCommand : public command
//{
//public:
//	solveCommand();
//	~solveCommand();
//	virtual void execute() {};
//private:
//
//};
//
//
//class fileSizeCommand : public command
//{
//public:
//	fileSizeCommand();
//	~fileSizeCommand();
//	virtual void execute() {};
//private:
//
//};
//
//
////class controller {
////public:
////	controller(maze myMaze) {
////		m_commands[dir] = new mazecommand(myMaze);
////	}
////	command* get(const string& command)
////	{
////		auto it = m_commands.find(command);
////		if (it == m_commands.end())
////			return nullptr;
////
////		return it->second;
////	}
////	~controller() {}
////private:
////	map<string, command*> m_commands;
////};
//
//
//
//class generateMazeCommand : public command {
//private:
//	string _name;
//	int _size;
//public:
//	generateMazeCommand(string name, int size) : _name(name), _size(size) {}
//	virtual void execute()
//	{
//		cout << "Maze " << _name << "is ready" << endl;
//	}
//};
//
//
//class dirCommand : public command
//{
//private:
//
//public:
//	dirCommand();
//	~dirCommand();
//
//	virtual void execute(char* dir_name) {
//		DIR* _dir;
//		struct dirent* dire;
//		struct stat sta;
//		_dir = opendir(dir_name);
//		if (!_dir) {
//			cout << "Not found" << endl;
//		}
//		while ((dire = readdir(_dir)) != NULL)
//		{
//			if (dire->d_name[0] != '.') {
//				string path = string(dir_name) + "/" + string(dire->d_name);
//				cout << path << endl;
//				stat(path.c_str(), &sta);
//				if (S_ISDIR(sta.st_mode)) {
//					execute((char*)path.c_str());
//				}
//			}
//		}
//		closedir(_dir);
//	}
//};
//
//
//
//class displayCommand : public command {
//private:
//	maze _myMaze;
//	string _name;
//	Maze2dGenerator* _print;
//public:
//	displayCommand(const maze& mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		cout << _name << endl;
//		_print.print();
//	}
//};
//
//
//class saveMazeCommand : public command
//{
//private:
//	maze* _myMaze;
//	string _name;
//	ofstream& out_file;
//public:
//	saveMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		char* sizeN = _strlen(_name);
//		out_file.write((char*)&sizeN, sizeof(int))
//			out_file.write(_name, sizeN);
//		vector<char> mymaze = compress(_myMaze);
//		for (int i = 0; i < myMaze.size(); i++)
//			out_file.write((vector<char>) & mymaze[i], sizeof(vector<char>));
//	}
//}
//
////class saveMazeCommand : public command
////{
////private:
////	maze* _myMaze;
////	string _name;
////public:
////	saveMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
////	void execute()
////	{
////		if (!contEnd(_name, ".bin"))
////			_name += ".bin";
////		const char* fname = _name.c_str();
////		ofstream file;
////		file.open(fname);
////		file.close();
////	}
////};
//
//class loadMazeCommand : public command
//{
//public:
//	loadMazeCommand(maze* mymaze, string name) : _myMaze(mymaze), _name(name) {}
//	void execute()
//	{
//		int name_len = 0;
//		in_file.read((char*)&name_len, sizeof(int));
//		_name = new char[name_len + 1];
//
//		if (_name == nullptr)
//			throw "bad memory allocation";
//
//		in_file.read(_name, name_len);
//		_name[name_len] = '\0';
//		vector<char> mymaze;
//		for (int i = 0; in_file != EOF; i++)
//			in_file.read((vector<char>) & mymaze[i], sizeof(vector<char>));
//		vector<vector<int>> unmaze = uncompress(mymaze);
//
//	}
//
//private:
//	ifstream& in_file;
//	string _name;
//	maze* _myMaze;
//};
//
//
//
//class view
//{
//public:
//	view();
//	~view();
//	void printMaze();
//	void printSolution();
//
//private:
//
//};
//
//
//class controler
//{
//public:
//	controler();
//	~controler();
//
//private:
//
//};
//
//class model
//{
//public:
//	model();
//	~model();
//
//private:
//	MazeGeneratorInterface* _generator;
//	searcher<mazeState>* _Astar;
//	searcher<mazeState>* _BFS;
//	searchable<mazeState>* _searchable;
//};
//



vector<int> compress(vector<int> ans)
{
	vector<int> comp, final;
	string tmp;

	//vector<int> ans{ 3,'g','u','y',12,0,0,3,3,   1,1,1,1,   1,0,0,1,   1,1,0,0   ,1,1,0,0   ,1,1,0,0   ,1,1,0,0 };

	int num = ans[0];
	comp.push_back(ans[0]);

	int i;
	for (i = 1; i <= num; i++)
		comp.push_back(ans[i]);


	for(int j = 0  ; j < 5 ; j++ )
		comp.push_back(ans[i++]);

	
	for (i; i < ans.size();)
	{
		tmp.clear();
		for (int j = 0; j < 4; j++)
			tmp += ans[i++]+ 48;

		if (tmp == "0000")
			comp.push_back('a');

		if (tmp == "0001")
			comp.push_back('b');

		if (tmp == "0010")
			comp.push_back('c');

		if (tmp == "0011")
			comp.push_back('d');

		if (tmp == "0100")
			comp.push_back('e');

		if (tmp == "0101")
			comp.push_back('f');

		if (tmp == "0110")
			comp.push_back('g');

		if (tmp == "0111")
			comp.push_back('h');

		if (tmp == "1000")
			comp.push_back('i');

		if (tmp == "1001")
			comp.push_back('j');

		if (tmp == "1010")
			comp.push_back('k');

		if (tmp == "1011")
			comp.push_back('l');

		if (tmp == "1100")
			comp.push_back('m');

		if (tmp == "1101")
			comp.push_back('n');

		if (tmp == "1110")
			comp.push_back('o');

		if (tmp == "1111")
			comp.push_back('p');

	}

	num = comp[0];
	final.push_back(comp[0]);

	for (i = 1; i <= num; i++)
		final.push_back(comp[i]);


	for (int j = 0; j < 5; j++)
		final.push_back(comp[i++]);

	
	for (i; i < comp.size();)
	{
		int count = 1;
		while (i + 1 < comp.size() && comp[i] == comp[i + 1])
		{
			count++;
			i++;
		}
		if (count > 3)
		{
			final.push_back('X');
			final.push_back(count);
			final.push_back(comp[i++]);
		}
		else
			final.push_back(comp[i++]);
	
	}
	return final;
}

vector<vector<int>> uncompress(vector<int> final)
{
	//vector<int> first;
	vector<vector<int>> first;
	string tmp;

	first.resize(2);
	//vector<int> ans{ 3,'g','u','y'    ,12,0,0,3,3,   a,   b,  x,  4,  d};

	int num = final[0];
	int i;
	int row = 0;

	for (i = 1 ; i <= num; i++)
		first[row].push_back(final[i]);

	row++;

	for (int j = 0; j < 5; j++)
		first[row].push_back(final[i++]);

	row++;


	vector<int> vec;
	int index;
	for (i; i < final.size(); i++)
	{
		num = 1;
		if (final[i] == 'X')
		{
			num = final[++i];
			i++;;
		}

		tmp.clear();
		if (final[i] == 'a')
			tmp = "0000";

		if(final[i] == 'b')
			tmp = "0001";

		if (final[i] == 'c')
			tmp = "0010";

		if (final[i] == 'd')
			tmp = "0011";

		if (final[i] == 'e')
			tmp = "0100";

		if (final[i] == 'f')
			tmp = "0101";

		if (final[i] == 'g')
			tmp = "0110";

		if (final[i] == 'h')
			tmp = "0111";

		if (final[i] == 'i')
			tmp = "1000";

		if (final[i] == 'j')
			tmp = "1001";

		if (final[i] == 'k')
			tmp = "1010";

		if (final[i] == 'l')
			tmp = "1011";

		if (final[i] == 'm')
			tmp = "1100";

		if (final[i] == 'n')
			tmp = "1101";

		if (final[i] == 'o')
			tmp = "1110";

		if (final[i] == 'p')
			tmp = "1111";

		for (int n = 0; n < num; n++)
		{
			first.push_back(vec);
			for (int t = 0; t < 4; t++)
				first[row].push_back(tmp[t] - 48);

			row++;
		}
	}


	return first;

};

int main()
{
	vector<int> ans{ 3,'g','u','y' ,12,3,3,0,0, 1,1,1,1 ,1,0,0,1 ,1,1,0,0 ,1,1,0,0 ,1,1,0,0, 1,1,0,0 };
	vector<int> final = compress(ans);

	for (int i = 0; i < final.size(); i++)
	{
		if (final[i] < 48)
			cout << final[i] << " ";
		else
			cout.put(final[i]) << " ";
	}

	cout << endl;
	vector<vector<int>> uncomp = uncompress(final);
	for (int i = 0; i < uncomp.size(); i++)
	{
		for (int j = 0; j < uncomp[i].size(); j++)
			cout << uncomp[i][j] << " ";

		cout << endl;
	}


}


//int main()
//{
//
//
//    //Test t;
//    //Test t2;
//    //t.testGenerator(*new simpleMaze2dGenerator);
//    //t2.testGenerator(*new myMaze2dGenerator);
//
//    Demo d;
//
//    char* leak = new char;
//
//    d.run(25, "guy");
//
// //   myMaze2dGenerator a;
//	//Maze2d b = a.generate(4, "guy");
//
//	//mazeSearchable tmp(b);
// //   
// //   Astar alg(new MazeManheten());
// //   b.print();
//	//Solution<mazeState<cell>> ans = alg.search(&tmp);
//
// //   b.print(&ans.getSolution());
//
// //   int x = 5;
//	
//}

